@echo off
setlocal
set PORT=8001
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" launcher.py
) else (
    where py >nul 2>nul
    if not errorlevel 1 (
        py -3 launcher.py
    ) else (
        python launcher.py
    )
)
if errorlevel 1 (
    echo.
    echo CollegeNotice could not start. The error is shown above.
    echo Keep this window open and share the final error lines.
    pause
)


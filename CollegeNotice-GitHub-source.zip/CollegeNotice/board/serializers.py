from pathlib import Path
from PIL import Image
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError as DjangoValidationError
from django.utils import timezone
from rest_framework import serializers
from .models import Category, Department, Notice, User


def can_manage(user, notice=None):
    if user.is_superuser:
        return True
    return user.role == 'admin' and bool(user.department_id) and (notice is None or notice.department_id == user.department_id)


class UserSerializer(serializers.ModelSerializer):
    name = serializers.CharField(source='first_name', max_length=150)
    department_name = serializers.CharField(source='department.name', read_only=True, default='Campus')
    class Meta:
        model = User
        fields = ['id', 'name', 'email', 'role', 'department', 'department_name', 'email_alerts', 'is_superuser']
        read_only_fields = ['id', 'email', 'role', 'department', 'is_superuser']


class RegisterSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=150)
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True, max_length=128)
    department = serializers.PrimaryKeyRelatedField(queryset=Department.objects.all())

    def validate(self, data):
        data['email'] = data['email'].lower()
        if User.objects.filter(email__iexact=data['email']).exists():
            raise serializers.ValidationError({'email': 'This email is already registered.'})
        try:
            validate_password(data['password'], User(email=data['email'], username=data['email'], first_name=data['name']))
        except DjangoValidationError as exc:
            raise serializers.ValidationError({'password': list(exc.messages)})
        return data

    def create(self, data):
        return User.objects.create_user(username=data['email'], email=data['email'], password=data['password'],
                                        first_name=data['name'], department=data['department'], role='student')


class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ['id', 'name', 'description']


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name', 'description']


class NoticeSerializer(serializers.ModelSerializer):
    department_name = serializers.CharField(source='department.name', read_only=True, default='All departments')
    category_name = serializers.CharField(source='category.name', read_only=True)
    author = serializers.CharField(source='created_by.first_name', read_only=True)
    bookmarked = serializers.SerializerMethodField()
    translation_language = serializers.SerializerMethodField()
    editable = serializers.SerializerMethodField()
    attachment_url = serializers.SerializerMethodField()
    attachment = serializers.FileField(write_only=True, required=False, allow_null=True)
    clear_attachment = serializers.BooleanField(write_only=True, required=False, default=False)
    is_active = serializers.BooleanField(read_only=True)

    class Meta:
        model = Notice
        fields = ['id', 'title', 'body', 'summary', 'translation', 'translation_language', 'ai_status', 'priority', 'priority_reason',
                  'force_priority', 'department', 'department_name', 'category', 'category_name', 'author',
                  'publish_date', 'expiry_date', 'archived', 'created_at', 'updated_at', 'bookmarked', 'editable',
                  'attachment', 'attachment_name', 'attachment_url', 'clear_attachment', 'is_active']
        read_only_fields = ['summary', 'translation', 'translation_language', 'ai_status', 'priority', 'priority_reason', 'attachment_name', 'created_at', 'updated_at']

    def get_bookmarked(self, obj):
        ids = self.context.get('bookmark_ids')
        return obj.pk in ids if ids is not None else obj.bookmarks.filter(user=self.context['request'].user).exists()

    def get_translation_language(self, obj):
        from .ai import translation_target
        return translation_target(obj.body)

    def get_editable(self, obj):
        return can_manage(self.context['request'].user, obj)

    def get_attachment_url(self, obj):
        return f'/api/notices/{obj.pk}/attachment/' if obj.attachment else None

    def validate_attachment(self, file):
        if file is None:
            return None
        if file.size > 5 * 1024 * 1024:
            raise serializers.ValidationError('Attachments must be 5 MB or smaller.')
        suffix = Path(file.name).suffix.lower()
        header = file.read(8)
        file.seek(0)
        if suffix == '.pdf':
            if not header.startswith(b'%PDF-'):
                raise serializers.ValidationError('Invalid PDF file.')
        elif suffix in ['.png', '.jpg', '.jpeg']:
            try:
                picture = Image.open(file)
                if picture.format not in ['PNG', 'JPEG']:
                    raise ValueError('Invalid image')
                picture.verify()
            except Exception:
                raise serializers.ValidationError('Invalid PNG or JPEG image.')
            finally:
                file.seek(0)
        else:
            raise serializers.ValidationError('Only PDF, PNG and JPEG files are allowed.')
        return file

    def validate(self, data):
        user = self.context['request'].user
        dept = data.get('department', self.instance.department if self.instance else None)
        if not user.is_superuser and (not dept or dept.pk != user.department_id):
            raise serializers.ValidationError({'department': 'You may publish only to your own department.'})
        start = data.get('publish_date', self.instance.publish_date if self.instance else timezone.localdate())
        end = data.get('expiry_date', self.instance.expiry_date if self.instance else None)
        if start > timezone.localdate():
            raise serializers.ValidationError({'publish_date': 'Future scheduling is not supported; publish today or earlier.'})
        if end and end < start:
            raise serializers.ValidationError({'expiry_date': 'Expiry cannot be earlier than publication.'})
        if not self.instance and end and end < timezone.localdate():
            raise serializers.ValidationError({'expiry_date': 'A new notice must expire today or later.'})
        if data.get('archived') is False and end and end < timezone.localdate():
            raise serializers.ValidationError({'expiry_date': 'Extend the expiry date before restoring this notice.'})
        return data

"""CPU-only offline NLLB inference. No network operations or runtime downloads."""
import re
from functools import lru_cache
from pathlib import Path
from threading import Lock
from django.conf import settings
from .translation import TranslationError

LANGUAGES = {'en': 'eng_Latn', 'ml': 'mal_Mlym'}
_lock = Lock()


def ready():
    path = Path(settings.LOCAL_TRANSLATION_MODEL_DIR)
    return all((path / name).is_file() for name in ('model.bin', 'config.json', 'shared_vocabulary.txt', 'sentencepiece.bpe.model'))


@lru_cache(maxsize=1)
def _engine(directory):
    try:
        import ctranslate2
        import sentencepiece
        tokenizer = sentencepiece.SentencePieceProcessor(model_file=str(Path(directory) / 'sentencepiece.bpe.model'))
        translator = ctranslate2.Translator(directory, device='cpu', compute_type='int8', inter_threads=1, intra_threads=4)
        return tokenizer, translator
    except Exception:
        raise TranslationError('Local translation could not load. Run setup-local-translation.bat and restart the server.') from None


def local_translate(text, target, source=None):
    if not isinstance(text, str) or not text.strip() or len(text) > 20000:
        raise TranslationError('Enter text between 1 and 20,000 characters.')
    source = source or ('ml' if re.search(r'[\u0d00-\u0d7f]', text) else 'en')
    if source not in LANGUAGES or target not in LANGUAGES:
        raise TranslationError('Choose English or Malayalam.')
    if source == target:
        return text
    if not ready():
        raise TranslationError('Local model is not installed. Run setup-local-translation.bat once.')
    # A single shared model avoids loading hundreds of MB for each request.
    with _lock:
        tokenizer, translator = _engine(str(settings.LOCAL_TRANSLATION_MODEL_DIR))
        output = []
        try:
            # Keep paragraph breaks; translate sentences and token-limited chunks.
            # No input tokens are silently truncated, including very long words.
            for paragraph in re.split(r'(\n+)', text):
                if not paragraph.strip():
                    output.append(paragraph)
                    continue
                sentences = re.split(r'(?<=[.!?।])\s+', paragraph.strip())
                translated = []
                for sentence in sentences:
                    tokens = tokenizer.encode(sentence, out_type=str)
                    for offset in range(0, len(tokens), 200):
                        batch = [LANGUAGES[source]] + tokens[offset:offset + 200] + ['</s>']
                        result = translator.translate_batch([batch], target_prefix=[[LANGUAGES[target]]],
                            beam_size=2, max_decoding_length=512, max_input_length=0)[0]
                        hypothesis = result.hypotheses[0]
                        if len(hypothesis) >= 512:
                            raise TranslationError('Translation reached its output limit. Try shorter sentences.')
                        pieces = [p for p in hypothesis if p not in (LANGUAGES[target], '</s>', '<s>')]
                        value = tokenizer.decode(pieces).strip()
                        if not value:
                            raise TranslationError('The local model returned no translation. Try a complete sentence.')
                        translated.append(value)
                output.append(' '.join(translated))
            return ''.join(output)
        except TranslationError:
            raise
        except Exception:
            raise TranslationError('Local translation failed. Try shorter text or restart the server.') from None

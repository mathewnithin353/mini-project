from types import SimpleNamespace
from django.test import SimpleTestCase
from board.ai import local_analysis, answer


class AssistanceTests(SimpleTestCase):
    def test_summary_uses_original_sentences_and_preserves_time(self):
        body = 'Welcome to the department. The seminar starts at 2:00 p.m. in Hall A. Submit your report by 12 October.'
        result = local_analysis('Seminar', body)
        sentences = result['summary'].splitlines()
        self.assertLessEqual(len(sentences), 2)
        for sentence in sentences:
            self.assertIn(sentence, body)
        self.assertIn('2:00 p.m. in Hall A.', result['summary'])

    def test_priority_in_both_languages_and_ordinary_notice(self):
        for body in ['The examination timetable is revised.', 'Submit your report by Friday.', 'പരീക്ഷ നാളെ നടക്കും.']:
            result = local_analysis('Notice', body)
            self.assertTrue(result['priority'])
            self.assertTrue(result['priority_reason'])
        self.assertFalse(local_analysis('Library', 'New books are available.')['priority'])

    def notices(self):
        return [SimpleNamespace(id=1, title='API seminar', body='Django workshop in Hall A.',
                    translation='സെമിനാർ', category=SimpleNamespace(name='Events'),
                    department='MCA', summary='Django workshop in Hall A.', priority=False),
                SimpleNamespace(id=2, title='Exam deadline', body='Submit by Friday.',
                    translation='പരീക്ഷ', category=SimpleNamespace(name='Exams'),
                    department='MCA', summary='Submit by Friday.', priority=True)]

    def test_chat_returns_matching_sources_and_original_excerpt(self):
        result = answer('Django seminar', self.notices())
        self.assertEqual(result['sources'], [{'id': 1, 'title': 'API seminar'}])
        self.assertIn('[1]', result['reply'])
        self.assertIn('Django workshop in Hall A.', result['reply'])

    def test_chat_searches_malayalam_translation(self):
        self.assertEqual(answer('പരീക്ഷ', self.notices())['sources'][0]['id'], 2)

    def test_chat_priority_and_no_match(self):
        self.assertEqual([s['id'] for s in answer('priority notices', self.notices())['sources']], [2])
        result = answer('unrelatedxyz', self.notices())
        self.assertEqual(result['sources'], [])
        self.assertIn('could not find', result['reply'])

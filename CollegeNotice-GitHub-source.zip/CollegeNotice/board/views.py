import csv
from PIL import Image, UnidentifiedImageError
from datetime import date
from functools import partial
from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.db import transaction
from django.db.models import Count, Q
from django.db.models.deletion import ProtectedError
from django.http import FileResponse, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, render
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_protect, ensure_csrf_cookie
from django.views.decorators.cache import never_cache
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied, ValidationError
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView
from . import ai, local_chat
from .models import Activity, Bookmark, Category, Department, EmailDelivery, Notice, Notification, User
from .serializers import CategorySerializer, DepartmentSerializer, NoticeSerializer, RegisterSerializer, UserSerializer, can_manage
from .tasks import archive_expired, create_alerts, enqueue_outbox, process_outbox


@ensure_csrf_cookie
@never_cache
def index(request):
    return render(request, 'index.html')


def service_worker(request):
    response = HttpResponse((settings.BASE_DIR / 'static' / 'sw.js').read_text(encoding='utf-8'), content_type='application/javascript')
    response['Cache-Control'] = 'no-cache'
    response['Service-Worker-Allowed'] = '/'
    return response


class Bootstrap(APIView):
    permission_classes = [AllowAny]
    def get(self, request):
        return Response({'user': UserSerializer(request.user).data if request.user.is_authenticated else None,
                         'departments': DepartmentSerializer(Department.objects.all(), many=True).data,
                         'categories': CategorySerializer(Category.objects.all(), many=True).data,
                         'demo': settings.DEMO_MODE,
                         'chat_available': local_chat.configured(),
                         'services': {'ai': ai.service_label(),
                                      'chat': 'Local general chat configured' if local_chat.configured() else 'College notice search available',
                                      'email': 'SMTP configured' if settings.EMAIL_BACKEND.endswith('smtp.EmailBackend') else 'Demo email files · not delivered',
                                      'tasks': 'Immediate demo tasks' if settings.CELERY_TASK_ALWAYS_EAGER else 'Celery + Redis configured',
                                      'database': 'PostgreSQL' if 'postgresql' in settings.DATABASES['default']['ENGINE'] else 'SQLite demo'},
                         'today': timezone.localdate().isoformat()})


class TranslateText(APIView):
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'ai'

    def post(self, request):
        from .local_translation import local_translate
        from .translation import TranslationError
        text = request.data.get('text', '')
        target = request.data.get('target', 'ml')
        source = request.data.get('source', 'auto')
        if not isinstance(text, str) or not text.strip() or len(text) > 5000:
            raise ValidationError('Enter between 1 and 5,000 characters.')
        if source not in ('auto', 'en', 'ml') or target not in ('en', 'ml'):
            raise ValidationError('Choose English or Malayalam.')
        try:
            translation = local_translate(text, target, None if source == 'auto' else source)
        except TranslationError as error:
            return Response({'detail': str(error)}, status=503)
        return Response({'translation': translation, 'target': target, 'mode': 'Local translation'})


class ThrottledTokenLogin(TokenObtainPairView):
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'login'


@method_decorator(csrf_protect, name='dispatch')
class Login(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'login'
    def post(self, request):
        email = str(request.data.get('email', '')).strip().lower()
        password = request.data.get('password', '')
        if not isinstance(password, str):
            raise ValidationError('Invalid credentials.')
        user = authenticate(request, username=email, password=password)
        if not user:
            return Response({'detail': 'Email or password is incorrect.'}, status=400)
        login(request, user)
        return Response(UserSerializer(user).data)


@method_decorator(csrf_protect, name='dispatch')
class Register(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'login'
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        login(request, user)
        return Response(UserSerializer(user).data, status=201)


class Logout(APIView):
    def post(self, request):
        logout(request)
        return Response({'ok': True})


class Profile(APIView):
    def get(self, request):
        return Response(UserSerializer(request.user).data)
    def patch(self, request):
        serializer = UserSerializer(request.user, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class ChangePassword(APIView):
    def post(self, request):
        from django.contrib.auth.password_validation import validate_password
        from django.contrib.auth import update_session_auth_hash
        from django.core.exceptions import ValidationError as PasswordError
        current, new = request.data.get('current_password'), request.data.get('new_password')
        if not isinstance(current, str) or not isinstance(new, str) or not request.user.check_password(current):
            raise ValidationError('The current password is incorrect.')
        try:
            validate_password(new, request.user)
        except PasswordError as exc:
            raise ValidationError(exc.messages)
        request.user.set_password(new)
        request.user.save(update_fields=['password'])
        update_session_auth_hash(request, request.user)
        return Response({'ok': True})


class NoticeViewSet(viewsets.ModelViewSet):
    throttle_scope = None
    serializer_class = NoticeSerializer
    http_method_names = ['get', 'post', 'patch', 'delete', 'head', 'options']

    def get_queryset(self):
        qs = Notice.objects.select_related('category', 'department', 'created_by')
        user = self.request.user
        state = self.request.query_params.get('state', 'active')
        if self.action in ['partial_update', 'destroy']:
            return qs if user.is_superuser else qs.filter(department_id=user.department_id) if can_manage(user) else qs.none()
        if state == 'archived' and can_manage(user):
            qs = qs.filter(Q(archived=True) | Q(expiry_date__lt=timezone.localdate()))
            if not user.is_superuser:
                qs = qs.filter(department_id=user.department_id)
        else:
            qs = qs.active()
        params = self.request.query_params
        for key in ['department', 'category']:
            value = params.get(key)
            if value:
                if key == 'department' and value == 'campus':
                    qs = qs.filter(department__isnull=True)
                elif value.isdigit():
                    qs = qs.filter(**{f'{key}_id': int(value)})
                else:
                    raise ValidationError({key: 'Invalid filter.'})
        if params.get('q'):
            q = params['q'][:200]
            for keyword in q.split():
                qs = qs.filter(Q(title__icontains=keyword) | Q(body__icontains=keyword) | Q(translation__icontains=keyword))
        dates = {}
        for key, lookup in [('from', 'publish_date__gte'), ('to', 'publish_date__lte')]:
            if params.get(key):
                try:
                    value = date.fromisoformat(params[key])
                except ValueError:
                    raise ValidationError({key: 'Use a valid YYYY-MM-DD date.'})
                dates[key] = value
                qs = qs.filter(**{lookup: value})
        if dates.get('from') and dates.get('to') and dates['from'] > dates['to']:
            raise ValidationError({'to': 'End date must be on or after the start date.'})
        if params.get('priority') == '1':
            qs = qs.filter(priority=True)
        if params.get('saved') == '1':
            qs = qs.filter(bookmarks__user=user)
        return qs

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['bookmark_ids'] = set(Bookmark.objects.filter(user=self.request.user).values_list('notice_id', flat=True))
        return context

    def perform_create(self, serializer):
        if not can_manage(self.request.user):
            raise PermissionDenied('Only department admins can publish notices.')
        data = serializer.validated_data
        result = ai.analyze(data['title'], data['body'])
        if data.get('force_priority'):
            result.update(priority=True, priority_reason='Marked urgent by the publisher')
        attachment = data.get('attachment')
        data.pop('clear_attachment', None)
        with transaction.atomic():
            notice = serializer.save(created_by=self.request.user, attachment_name=attachment.name[:200] if attachment else '', **result)
            Activity.objects.create(actor=self.request.user, message=f'Published: {notice.title}')
            if notice.is_active:
                create_alerts(notice)
            transaction.on_commit(enqueue_outbox)

    def perform_update(self, serializer):
        old = serializer.instance
        if not can_manage(self.request.user, old):
            raise PermissionDenied('This notice belongs to another department.')
        data = serializer.validated_data
        clear = data.pop('clear_attachment', False)
        result = ai.analyze(data.get('title', old.title), data.get('body', old.body))
        if data.get('force_priority', old.force_priority):
            result.update(priority=True, priority_reason='Marked urgent by the publisher')
        old_file = old.attachment.name
        if data.get('attachment'):
            result['attachment_name'] = data['attachment'].name[:200]
        elif clear:
            result.update(attachment=None, attachment_name='')
        with transaction.atomic():
            notice = serializer.save(**result)
            Activity.objects.create(actor=self.request.user, message=f'Updated: {notice.title}')
            if notice.is_active:
                create_alerts(notice)
                transaction.on_commit(enqueue_outbox)
            if old_file and old_file != notice.attachment.name:
                transaction.on_commit(partial(old.attachment.storage.delete, old_file))

    def perform_destroy(self, instance):
        if not can_manage(self.request.user, instance):
            raise PermissionDenied('This notice belongs to another department.')
        with transaction.atomic():
            Activity.objects.create(actor=self.request.user, message=f'Deleted: {instance.title}')
            file, storage = instance.attachment.name, instance.attachment.storage
            instance.delete()
            if file:
                transaction.on_commit(partial(storage.delete, file))

    @action(detail=True, methods=['post'], throttle_classes=[ScopedRateThrottle], throttle_scope='ai')
    def translate(self, request, pk=None):
        notice = self.get_object()
        from .local_translation import local_translate
        from .translation import TranslationError
        target = ai.translation_target(notice.body)
        try:
            translated = notice.translation or local_translate(notice.body, target)
        except TranslationError as error:
            return Response({'detail': str(error)}, status=503)
        # Reading a translation never edits the notice or queues email alerts.
        return Response({'translation': translated, 'target': target})

    @action(detail=True, methods=['post', 'delete'])
    def bookmark(self, request, pk=None):
        notice = self.get_object()
        if request.method == 'DELETE':
            Bookmark.objects.filter(user=request.user, notice=notice).delete()
            return Response({'bookmarked': False})
        Bookmark.objects.get_or_create(user=request.user, notice=notice)
        return Response({'bookmarked': True})

    @action(detail=True, methods=['get'])
    def attachment(self, request, pk=None):
        notice = self.get_object()
        if not notice.attachment:
            return Response({'detail': 'No attachment.'}, status=404)
        try:
            preview = request.query_params.get('preview') == '1'
            content_type = None
            if preview:
                # Only validated raster images may be served inline. Detect the
                # actual format because an upload's extension can be misleading.
                with notice.attachment.open('rb') as source:
                    try:
                        picture = Image.open(source)
                        content_type = {'PNG': 'image/png', 'JPEG': 'image/jpeg'}.get(picture.format)
                        picture.verify()
                    except (UnidentifiedImageError, OSError, ValueError, SyntaxError):
                        content_type = None
                if not content_type:
                    return Response({'detail': 'Preview is available only for PNG and JPEG images.'}, status=400)
            response = FileResponse(notice.attachment.open('rb'), as_attachment=not preview,
                                    filename=notice.attachment_name, content_type=content_type)
            response['Cache-Control'] = 'private, no-store'
            response['X-Content-Type-Options'] = 'nosniff'
            return response
        except FileNotFoundError:
            return Response({'detail': 'Attachment file is unavailable.'}, status=404)


class CatalogViewSet(viewsets.ModelViewSet):
    pagination_class = None
    http_method_names = ['get', 'post', 'patch', 'delete', 'head', 'options']
    def _check(self):
        if not can_manage(self.request.user):
            raise PermissionDenied('Only admins can manage the catalogue.')
    def perform_create(self, serializer):
        self._check()
        serializer.save()
    def perform_update(self, serializer):
        self._check()
        serializer.save()
    def perform_destroy(self, instance):
        self._check()
        try:
            instance.delete()
        except ProtectedError:
            raise ValidationError('This item is in use and cannot be deleted.')


class Departments(CatalogViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer


class Categories(CatalogViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class Notifications(APIView):
    def get(self, request):
        qs = Notification.objects.filter(user=request.user)
        return Response({'unread': qs.filter(is_read=False).count(),
                         'items': list(qs.values('id', 'notice_id', 'message', 'is_read', 'created_at')[:100])})
    def post(self, request):
        qs = Notification.objects.filter(user=request.user)
        pk = request.data.get('id')
        if pk is not None:
            if not isinstance(pk, int):
                raise ValidationError('Invalid notification ID.')
            qs = qs.filter(pk=pk)
        qs.update(is_read=True)
        return Response({'ok': True})


class Chat(APIView):
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'ai'
    def post(self, request):
        question = request.data.get('question')
        if not isinstance(question, str) or not 1 <= len(question.strip()) <= 1000:
            raise ValidationError('Ask a question between 1 and 1,000 characters.')
        mode = request.data.get('mode', 'notices')
        if mode not in ['general', 'notices']:
            raise ValidationError('Choose General chat or College notices.')
        history = request.data.get('history', [])
        if not isinstance(history, list) or len(history) > 8:
            raise ValidationError('Conversation history must contain at most eight messages.')
        for message in history:
            if (not isinstance(message, dict) or message.get('role') not in ['user', 'assistant']
                    or not isinstance(message.get('content'), str)
                    or not 1 <= len(message['content']) <= 3000):
                raise ValidationError('Invalid conversation history.')
        if sum(len(message['content']) for message in history) > 6000:
            raise ValidationError('Conversation history is too long. Start a new chat.')
        history = [{'role': m['role'], 'content': m['content']} for m in history]
        if mode == 'general':
            try:
                return Response(local_chat.answer(question.strip(), history))
            except local_chat.ChatUnavailable as error:
                return Response({'detail': str(error)}, status=503)
        qs = Notice.objects.active().select_related('category', 'department')
        return Response(ai.answer(question.strip(), list(qs[:500])))


class Dashboard(APIView):
    def scoped_notices(self, request):
        if not can_manage(request.user):
            raise PermissionDenied('Admins only.')
        qs = Notice.objects.all()
        return qs if request.user.is_superuser else qs.filter(department_id=request.user.department_id)

    def get(self, request):
        qs = self.scoped_notices(request)
        today = timezone.localdate()
        emails = EmailDelivery.objects.filter(notice__in=qs)
        activity = Activity.objects.all()
        if not request.user.is_superuser:
            activity = activity.filter(actor__department_id=request.user.department_id)
        return Response({'total': qs.count(), 'active': qs.active().count(), 'priority': qs.active().filter(priority=True).count(),
                         'archived': qs.filter(Q(archived=True) | Q(expiry_date__lt=today)).count(),
                         'categories': list(qs.active().order_by().values('category__name').annotate(count=Count('id'))),
                         'emails': list(emails.order_by().values('status').annotate(count=Count('id'))),
                         'deliveries': list(emails.select_related('user', 'notice').order_by('-created_at').values(
                             'id', 'user__email', 'notice__title', 'status', 'attempts', 'last_error')[:30]),
                         'activity': list(activity.values('message', 'created_at')[:30])})

    def post(self, request):
        qs = self.scoped_notices(request)
        # Explicit retry is scoped to the administrator's department.
        emails = EmailDelivery.objects.filter(notice__in=qs, status='failed')
        emails.update(status='pending', attempts=0, last_error='')
        enqueue_outbox()
        return Response({'detail': 'Pending and failed email jobs queued for processing.'})


class Export(Dashboard):
    def get(self, request):
        qs = self.scoped_notices(request).select_related('category', 'department')
        response = HttpResponse(content_type='text/csv; charset=utf-8')
        response['Content-Disposition'] = 'attachment; filename="notice-report.csv"'
        writer = csv.writer(response)
        writer.writerow(['ID', 'Title', 'Department', 'Category', 'Published', 'Expires', 'Priority', 'Active'])
        def safe(value):
            text = str(value)
            return "'" + text if text.startswith(('=', '+', '-', '@', '\t', '\r')) else text
        for n in qs:
            writer.writerow([n.id, safe(n.title), safe(n.department or 'All departments'), safe(n.category), n.publish_date, n.expiry_date, n.priority, n.is_active])
        return response

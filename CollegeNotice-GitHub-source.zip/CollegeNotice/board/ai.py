"""Local notice analysis, translation and source-based answers."""
import logging
import re
import unicodedata
from collections import Counter

logger = logging.getLogger(__name__)
STOP = set('the a an is are was were to for of in on and or with by from this that will be at it what when which show me notices notice please about'.split())

def terms(text):
    # Keep combining vowel signs and viramas attached to Malayalam letters.
    normalized = unicodedata.normalize('NFC', text).lower()
    separated = ''.join(c if unicodedata.category(c)[0] in 'LNM' else ' ' for c in normalized)
    return [w for w in separated.split() if len(w) > 2 and w not in STOP]


def translation_target(body):
    return 'en' if re.search(r'[\u0d00-\u0d7f]', body) else 'ml'

def local_analysis(title, body):
    # Preserve common abbreviations so times remain attached to their venue.
    protected = re.sub(r'\b(?:[ap]\.m\.|Dr\.|Mr\.|Mrs\.|Prof\.)', lambda m: m.group().replace('.', '․'), body, flags=re.I)
    sentences = [s.strip().replace('․', '.') for s in re.split(r'(?<=[.!?।])\s+|\n+', protected) if s.strip()]
    counts = Counter(terms(body))
    scored = sorted(enumerate(sentences), key=lambda x: sum(counts[w] for w in set(terms(x[1]))) / max(1, len(terms(x[1]))) + (2 if re.search(r'\d|deadline|last date', x[1], re.I) else 0), reverse=True)[:2]
    summary = '\n'.join(s for _, s in sorted(scored))[:700]
    text = title + '\n' + body
    rules = [(r'\b(urgent|immediately|cancelled|rescheduled|revised)\b', 'Urgent or changed information'),
             (r'\b(exam|examination|internal|timetable|deadline)\b|last date|due date|submit(?:\s+\w+){0,5}\s+by|registration closes', 'Exam or deadline information'),
             (r'പരീക്ഷ|അവസാന തീയതി|അടിയന്തിര', 'Malayalam exam or urgency terms')]
    reason = next((reason for pattern, reason in rules if re.search(pattern, text, re.I)), '')
    return {'summary': summary or body[:700], 'translation': '', 'priority': bool(reason), 'priority_reason': reason,
            'ai_status': 'local-translation-needed' if re.search(r'[\u0d00-\u0d7f]', body) else 'local'}

def translation_configured():
    from .local_translation import ready
    return ready()


def service_label():
    return 'Local translation ready · no API key' if translation_configured() else 'Local translation needs model download'


def analyze(title, body):
    result = local_analysis(title, body)
    from .local_translation import local_translate
    from .translation import TranslationError
    try:
        result['translation'] = local_translate(body, translation_target(body))
        result['ai_status'] = 'local-model'
    except TranslationError as error:
        logger.warning('%s', error)
        result['ai_status'] = 'local-model-unavailable'
    return result


def answer(question, notices):
    words = set(terms(question))
    ranked = []
    for n in notices:
        score = len(words & set(terms(f'{n.title} {n.body} {n.translation} {n.category.name} {n.department or "campus"}')))
        if re.search(r'urgent|priority', question, re.I):
            score = 10 if n.priority else 0
        if score:
            ranked.append((score, n))
    hits = [n for _, n in sorted(ranked, key=lambda x: x[0], reverse=True)[:5]]
    sources = [{'id': n.id, 'title': n.title} for n in hits]
    if not hits:
        return {'reply': 'I could not find an active notice matching that question. Try an exam, department, event or deadline keyword.', 'sources': [], 'mode': 'local search'}
    return {'reply': '\n\n'.join(f'[{n.id}] {n.title}\n{n.summary}' for n in hits), 'sources': sources, 'mode': 'local search'}

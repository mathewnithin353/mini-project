from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Department, Category, Notice, Bookmark, Notification, EmailDelivery, Activity

@admin.register(User)
class CollegeUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (('College', {'fields': ('role', 'department', 'email_alerts')}),)
    list_display = ('username', 'first_name', 'role', 'department', 'is_active')

# Content uses the application workflows so AI, audit and notification hooks always run.
@admin.register(Notice, Bookmark, Notification, EmailDelivery, Activity)
class ReadOnlyAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def has_delete_permission(self, request, obj=None):
        return False

admin.site.register(Department)
admin.site.register(Category)
admin.site.site_header = 'CollegeNotice · User administration'

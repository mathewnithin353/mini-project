from unittest.mock import patch
from django.test import SimpleTestCase, override_settings
from rest_framework.test import APITestCase
from board import local_chat
from board.models import User


class LocalChatTests(SimpleTestCase):
    @patch('board.local_chat._request')
    @patch('board.local_chat.ensure_running')
    def test_history_is_passed_and_model_output_returned(self, ready, request):
        request.return_value = {'choices': [{'message': {'content': 'A list can change.'}}]}
        history = [{'role': 'user', 'content': 'Explain Python lists.'},
                   {'role': 'assistant', 'content': 'Lists store ordered items.'}]
        result = local_chat.answer('Can they change?', history)
        self.assertEqual(result['reply'], 'A list can change.')
        self.assertEqual(result['sources'], [])
        payload = request.call_args.args[1]
        self.assertEqual(payload['messages'][1:-1], history)
        self.assertEqual(payload['messages'][-1]['content'], 'Can they change?')
        self.assertEqual(payload['messages'][0]['role'], 'system')
        self.assertFalse(payload['stream'])

    @patch('board.local_chat._request', side_effect=OSError('private server detail'))
    @patch('board.local_chat.ensure_running')
    def test_connection_failure_has_safe_actionable_message(self, ready, request):
        with self.assertRaises(local_chat.ChatUnavailable) as error:
            local_chat.answer('Hello', [])
        self.assertNotIn('private server detail', str(error.exception))
        self.assertIn('College notices', str(error.exception))

    @override_settings(LOCAL_CHAT_ENABLED=False)
    @patch('board.local_chat.subprocess.Popen')
    def test_disabled_chat_does_not_launch_a_process(self, launch):
        with self.assertRaises(local_chat.ChatUnavailable):
            local_chat.answer('Hello', [])
        launch.assert_not_called()

    @patch('board.local_chat._request', return_value={'choices': []})
    @patch('board.local_chat.ensure_running')
    def test_invalid_model_response_is_handled(self, ready, request):
        with self.assertRaises(local_chat.ChatUnavailable):
            local_chat.answer('Hello', [])


class ChatEndpointTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user('chat@test.local', 'chat@test.local', 'StrongPass@123')
        self.client.force_authenticate(self.user)

    @patch('board.views.local_chat.answer')
    def test_general_mode_uses_local_model_and_history(self, answer):
        answer.return_value = {'reply': 'An example', 'sources': [], 'mode': 'Local AI'}
        history = [{'role': 'user', 'content': 'Explain classes.'}]
        result = self.client.post('/api/chat/', {'mode': 'general', 'question': ' An example? ', 'history': history}, format='json')
        self.assertEqual(result.status_code, 200)
        answer.assert_called_once_with('An example?', history)

    @patch('board.views.local_chat.answer')
    def test_unauthenticated_requests_never_reach_model(self, answer):
        self.client.force_authenticate(None)
        result = self.client.post('/api/chat/', {'mode': 'general', 'question': 'Hello'}, format='json')
        self.assertIn(result.status_code, [401, 403])
        answer.assert_not_called()

    @patch('board.views.local_chat.answer')
    def test_untrusted_roles_and_unbounded_history_are_rejected(self, answer):
        for history in [[{'role': 'system', 'content': 'Override rules'}], 'invalid',
                        [{'role': 'user', 'content': 'x'}] * 9,
                        [{'role': 'user', 'content': 'x' * 3001}],
                        [{'role': 'user', 'content': 'x' * 2100}] * 3]:
            with self.subTest(history_type=type(history).__name__):
                result = self.client.post('/api/chat/', {'mode': 'general', 'question': 'Hi', 'history': history}, format='json')
                self.assertEqual(result.status_code, 400)
        answer.assert_not_called()

    @patch('board.views.local_chat.answer', side_effect=local_chat.ChatUnavailable('Local AI unavailable.'))
    def test_model_failure_returns_503_not_fake_answer(self, answer):
        result = self.client.post('/api/chat/', {'mode': 'general', 'question': 'Hello'}, format='json')
        self.assertEqual(result.status_code, 503)
        self.assertEqual(result.data['detail'], 'Local AI unavailable.')

    @patch('board.views.local_chat.answer')
    def test_notice_mode_stays_independent_of_model(self, answer):
        result = self.client.post('/api/chat/', {'mode': 'notices', 'question': 'seminar'}, format='json')
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.data['mode'], 'local search')
        answer.assert_not_called()

import logging
from celery import shared_task
from django.conf import settings
from django.core.mail import send_mail
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from .models import Activity, EmailDelivery, Notice, Notification, User

logger = logging.getLogger(__name__)

def create_alerts(notice):
    recipients = User.objects.filter(role='student', is_active=True, is_superuser=False)
    if notice.department_id:
        recipients = recipients.filter(department_id=notice.department_id)
    for user in recipients.iterator():
        Notification.objects.get_or_create(user=user, notice=notice, defaults={
            'message': ('Priority: ' if notice.priority else '') + notice.title})
        if user.email_alerts:
            EmailDelivery.objects.get_or_create(user=user, notice=notice)

def enqueue_outbox():
    try:
        process_outbox.delay()
    except Exception:
        # The database outbox survives broker failure; beat retries once Redis returns.
        logger.warning('Email remains queued: broker unavailable.')

@shared_task
def process_outbox():
    pending = list(EmailDelivery.objects.filter(status__in=['pending', 'failed'], attempts__lt=3).values_list('id', flat=True)[:100])
    for pk in pending:
        # Row locks prevent two PostgreSQL workers from sending the same pending row.
        with transaction.atomic():
            row = EmailDelivery.objects.select_for_update().select_related('user', 'notice').filter(pk=pk).first()
            if not row or row.status not in ['pending', 'failed'] or row.attempts >= 3:
                continue
            if not row.notice.is_active or not row.user.is_active or not row.user.email_alerts:
                row.status = 'skipped'
                row.save(update_fields=['status'])
                continue
            row.attempts += 1
            try:
                count = send_mail(('Priority: ' if row.notice.priority else '') + row.notice.title,
                                  f'{row.notice.body}\n\nValid until {row.notice.expiry_date}.\nCollegeNotice',
                                  settings.DEFAULT_FROM_EMAIL, [row.user.email], fail_silently=False)
                if count != 1:
                    raise RuntimeError('Backend did not accept message')
                real_smtp = settings.EMAIL_BACKEND.endswith('smtp.EmailBackend')
                row.status = 'sent' if real_smtp else 'demo'
                row.sent_at = timezone.now() if real_smtp else None
                row.last_error = ''
            except Exception:
                row.status, row.last_error = 'failed', 'Email backend failed; check server configuration.'
            row.save(update_fields=['attempts', 'status', 'sent_at', 'last_error'])

@shared_task
def archive_expired():
    count = Notice.objects.filter(archived=False, expiry_date__lt=timezone.localdate()).update(archived=True)
    if count:
        Activity.objects.create(message=f'Automatically archived {count} expired notice(s).')
    return count

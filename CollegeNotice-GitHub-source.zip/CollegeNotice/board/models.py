import uuid
from pathlib import Path
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone

class Department(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.CharField(max_length=250, blank=True)
    class Meta:
        ordering = ['name']
    def __str__(self):
        return self.name

class Category(models.Model):
    name = models.CharField(max_length=80, unique=True)
    description = models.CharField(max_length=250, blank=True)
    class Meta:
        ordering = ['name']
    def __str__(self):
        return self.name

class User(AbstractUser):
    email = models.EmailField(unique=True)
    role = models.CharField(max_length=16, choices=[('student', 'Student'), ('admin', 'Department admin')], default='student')
    department = models.ForeignKey(Department, null=True, blank=True, on_delete=models.PROTECT)
    email_alerts = models.BooleanField(default=True)

def attachment_path(instance, filename):
    return f'attachments/{uuid.uuid4().hex}{Path(filename).suffix.lower()}'

class NoticeQuerySet(models.QuerySet):
    def active(self):
        return self.filter(archived=False, publish_date__lte=timezone.localdate(), expiry_date__gte=timezone.localdate())

class Notice(models.Model):
    title = models.CharField(max_length=180)
    body = models.TextField(max_length=20000)
    summary = models.TextField(blank=True)
    translation = models.TextField(blank=True)
    ai_status = models.CharField(max_length=30, default='local')
    priority = models.BooleanField(default=False)
    priority_reason = models.CharField(max_length=250, blank=True)
    force_priority = models.BooleanField(default=False)
    department = models.ForeignKey(Department, null=True, blank=True, on_delete=models.PROTECT)
    category = models.ForeignKey(Category, on_delete=models.PROTECT)
    created_by = models.ForeignKey(User, on_delete=models.PROTECT)
    publish_date = models.DateField(default=timezone.localdate)
    expiry_date = models.DateField()
    archived = models.BooleanField(default=False)
    attachment = models.FileField(upload_to=attachment_path, blank=True)
    attachment_name = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = NoticeQuerySet.as_manager()
    class Meta:
        ordering = ['-priority', '-created_at']
        indexes = [models.Index(fields=['archived', 'expiry_date']), models.Index(fields=['department', 'category'])]
        constraints = [models.CheckConstraint(condition=models.Q(expiry_date__gte=models.F('publish_date')), name='expiry_after_publish')]
    def __str__(self):
        return self.title
    @property
    def is_active(self):
        return not self.archived and self.publish_date <= timezone.localdate() <= self.expiry_date

class Bookmark(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    notice = models.ForeignKey(Notice, on_delete=models.CASCADE, related_name='bookmarks')
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['user', 'notice'], name='unique_bookmark')]

class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    notice = models.ForeignKey(Notice, on_delete=models.CASCADE)
    message = models.CharField(max_length=250)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-created_at']
        constraints = [models.UniqueConstraint(fields=['user', 'notice'], name='unique_notice_notification')]

class EmailDelivery(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    notice = models.ForeignKey(Notice, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, default='pending')
    attempts = models.PositiveSmallIntegerField(default=0)
    last_error = models.CharField(max_length=200, blank=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['user', 'notice'], name='unique_email_delivery')]

class Activity(models.Model):
    actor = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    message = models.CharField(max_length=300)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-created_at']

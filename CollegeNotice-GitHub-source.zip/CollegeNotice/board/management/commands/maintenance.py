from django.core.management.base import BaseCommand
from board.tasks import archive_expired, process_outbox

class Command(BaseCommand):
    help = 'Archive expired notices and process queued emails once (use Celery beat for automation).'
    def handle(self, *args, **options):
        count = archive_expired()
        process_outbox()
        self.stdout.write(f'Archived {count} expired notice(s); email outbox processed.')

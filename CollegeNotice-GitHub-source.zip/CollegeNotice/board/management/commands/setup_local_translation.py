"""Explicit one-time download. Translation requests never download files."""
import hashlib
from pathlib import Path
from urllib.request import urlopen
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

REVISION = '302d78f00e6fdb50a1064059df7c392b735e9d05'
REPO = 'JustFrederik/nllb-200-distilled-600M-ct2-int8'
FILES = {
    'config.json': None,
    'shared_vocabulary.txt': None,
    'sentencepiece.bpe.model': '14bb8dfb35c0ffdea7bc01e56cea38b9e3d5efcdcb9c251d6b40538e1aab555a',
    'model.bin': 'ed1beaf75134de7505315a5223162f56acff397eff6b50638a500d3936fe707b',
}


class Command(BaseCommand):
    help = 'Download the pinned NLLB int8 model (~630 MB) for offline educational translation.'

    def handle(self, *args, **options):
        directory = Path(settings.LOCAL_TRANSLATION_MODEL_DIR)
        directory.mkdir(parents=True, exist_ok=True)
        self.stdout.write('NLLB-200 by Meta, CC-BY-NC-4.0; community CTranslate2 conversion by JustFrederik.')
        for name, expected in FILES.items():
            destination = directory / name
            if destination.exists():
                with destination.open('rb') as source:
                    valid = not expected or hashlib.file_digest(source, 'sha256').hexdigest() == expected
                if valid:
                    self.stdout.write(f'{name}: already downloaded.')
                    continue
            temporary = directory / (name + '.part')
            self.stdout.write(f'Downloading {name}...', ending='\n')
            self.stdout.flush()
            try:
                digest = hashlib.sha256()
                with urlopen(f'https://huggingface.co/{REPO}/resolve/{REVISION}/{name}', timeout=60) as response, temporary.open('wb') as target:
                    count, milestone = 0, 0
                    while chunk := response.read(1024 * 1024):
                        target.write(chunk)
                        digest.update(chunk)
                        count += len(chunk)
                        if count // (50 * 1024 * 1024) > milestone:
                            milestone = count // (50 * 1024 * 1024)
                            self.stdout.write(f'  {count // (1024 * 1024)} MB received')
                            self.stdout.flush()
                if expected and digest.hexdigest() != expected:
                    raise ValueError('Checksum mismatch')
                temporary.replace(destination)
            except Exception as error:
                raise CommandError(f'Download failed for {name} ({type(error).__name__}). Retry this command; existing completed files are preserved.') from None
        (directory / 'SOURCE.txt').write_text(f'Meta NLLB-200 distilled 600M. License: CC-BY-NC-4.0.\nConversion: {REPO}\nRevision: {REVISION}\nhttps://huggingface.co/facebook/nllb-200-distilled-600M\n', encoding='utf-8')
        self.stdout.write(self.style.SUCCESS('Local model files ready. Run check_services --test-translation.'))

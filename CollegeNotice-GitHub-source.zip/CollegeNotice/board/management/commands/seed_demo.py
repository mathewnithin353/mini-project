from datetime import timedelta
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone
from board.ai import local_analysis
from board.models import Activity, Bookmark, Category, Department, Notice, User
from board.tasks import create_alerts

class Command(BaseCommand):
    help = 'Create safe, fictional demo data without replacing existing data or passwords.'

    @transaction.atomic
    def handle(self, *args, **options):
        if not settings.DEMO_MODE:
            raise CommandError('Demo seeding is disabled. Set DEMO_MODE=1 only for a local demonstration.')
        mca = Department.objects.get_or_create(name='Computer Applications')[0]
        cse = Department.objects.get_or_create(name='Computer Science')[0]
        Department.objects.get_or_create(name='Electronics & Communication')
        categories = {name: Category.objects.get_or_create(name=name)[0] for name in ['Examinations', 'Academic', 'Events', 'Library', 'Placement']}
        users = {}
        for email, name, role, dept, superuser in [
            ('admin@college.test', 'Department Admin', 'admin', mca, False),
            ('student@college.test', 'Ananya Nair', 'student', mca, False),
            ('cse.admin@college.test', 'CSE Admin', 'admin', cse, False),
            ('cse.student@college.test', 'Arjun Menon', 'student', cse, False),
            ('coordinator@college.test', 'Campus Coordinator', 'admin', None, True),
        ]:
            user, created = User.objects.get_or_create(username=email, defaults={'email':email, 'first_name':name,
                'role':role, 'department':dept, 'is_superuser':superuser, 'is_staff':superuser})
            if created:
                user.set_password('College@12345')
                user.save()
            users[email] = user
        if Notice.objects.exists():
            self.stdout.write('Accounts/catalogue ready; existing notices preserved.')
            return
        day = timezone.localdate()
        fmt = lambda offset: (day + timedelta(days=offset)).strftime('%d %B %Y')
        rows = [
            ('S2 MCA internal examination timetable revised', f'The DBMS internal examination will take place on {fmt(3)} at 9:30 a.m. in the MCA lab block. Bring your college ID and arrive 15 minutes early. The previous afternoon slot is cancelled.', 'Examinations', mca, 5, 0),
            ('Build better APIs: a hands-on seminar', f'Join the Department of Computer Applications on {fmt(7)} at 2:00 p.m. in Seminar Hall A. Explore REST API design with Django. Bring a laptop for the guided practical session.', 'Events', mca, 8, -1),
            ('Library hours during stock verification', f'The college library will close for stock verification on {fmt(2)}. All book return dates for that day are extended to {fmt(4)}. The digital library remains available.', 'Library', None, 5, -2),
            ('ലൈബ്രറി അറിയിപ്പ്', 'കോളേജ് ലൈബ്രറിയിൽ പുതിയ പുസ്തകങ്ങൾ ലഭ്യമാണ്. വിദ്യാർത്ഥികൾക്ക് കോളേജ് ഐഡി ഉപയോഗിച്ച് പുസ്തകങ്ങൾ എടുക്കാം. കൂടുതൽ വിവരങ്ങൾക്ക് ലൈബ്രേറിയനെ ബന്ധപ്പെടുക.', 'Library', None, 10, -2),
            ('Campus placement preparation workshop', f'The placement cell invites students to a resume and interview workshop on {fmt(10)} at 10:00 a.m. in the auditorium. Registration closes on {fmt(8)}. Carry a printed resume.', 'Placement', None, 11, -3),
            ('Open-source project showcase', f'Computer Science students are invited to present their open-source projects on {fmt(12)} in Lab 2. Each team has ten minutes for a demonstration and questions.', 'Events', cse, 13, -3),
            ('MCA mini-project review guidelines', f'The next project review is on {fmt(6)}. Prepare the objectives, architecture diagram, working demonstration and test results. Submit your report by {fmt(5)} to the department office.', 'Academic', mca, 7, -4),
            ('Previous orientation programme', 'The department orientation programme has concluded. This announcement is retained in the archive for reference.', 'Academic', mca, -1, -8),
        ]
        for title, body, category, dept, end, start in rows:
            publisher = users['admin@college.test'] if dept==mca else users['cse.admin@college.test'] if dept==cse else users['coordinator@college.test']
            notice = Notice.objects.create(title=title, body=body, category=categories[category], department=dept,
                created_by=publisher, publish_date=day+timedelta(days=start), expiry_date=day+timedelta(days=end),
                archived=end<0, **local_analysis(title, body))
            if notice.is_active:
                create_alerts(notice)
            Activity.objects.create(actor=publisher, message=f'Published demo notice: {title}')
        Bookmark.objects.get_or_create(user=users['student@college.test'], notice=Notice.objects.get(title='Build better APIs: a hands-on seminar'))
        self.stdout.write(self.style.SUCCESS('Demo ready. Student/admin password: College@12345. All example addresses use .test.'))

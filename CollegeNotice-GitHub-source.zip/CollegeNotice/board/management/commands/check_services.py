"""No network calls without explicit flags. Never print keys or passwords."""
import sys
from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.management.base import BaseCommand, CommandError
from django.core.mail import send_mail
from django.core.validators import validate_email
from board.ai import analyze, translation_configured, service_label


class Command(BaseCommand):
    help = 'Check configuration; optionally test translation or send one explicitly requested email.'

    def add_arguments(self, parser):
        parser.add_argument('--test-translation', action='store_true', help='Test two short samples locally; no API requests are made.')
        parser.add_argument('--email-to', help='Send one test message to this address; no student mailing list is used.')

    def handle(self, *args, **options):
        if hasattr(sys.stdout, 'reconfigure'):
            sys.stdout.reconfigure(encoding='utf-8')
        self.stdout.write('Translation: ' + service_label() + ' (connection not yet tested)')
        smtp = settings.EMAIL_BACKEND.endswith('smtp.EmailBackend')
        self.stdout.write('Email: '+('SMTP selected (connection not yet tested)' if smtp else 'demo files only; no email delivered'))
        if options['test_translation']:
            if not translation_configured():
                raise CommandError('Run setup-local-translation.bat to install the local model.')
            for body, expected in [('The library opens at 9:00 a.m.', 'ml'), ('ലൈബ്രറി രാവിലെ ഒമ്പത് മണിക്ക് തുറക്കും.', 'en')]:
                result = analyze('Translation connection test', body)
                if result['ai_status'] != 'local-model':
                    raise CommandError('Local translation failed. Run setup-local-translation.bat and restart; check the model/runtime installation.')
                self.stdout.write(f'{expected}: {result["translation"]}')
            self.stdout.write(self.style.SUCCESS('Both translation requests succeeded. Review the sample wording for accuracy.'))
        recipient = options['email_to']
        if recipient:
            try:
                validate_email(recipient)
            except ValidationError:
                raise CommandError('Provide a valid recipient email address.')
            if recipient.lower().endswith('.test'):
                raise CommandError('Demo .test addresses cannot receive email. Use your real inbox.')
            if not smtp:
                raise CommandError('Set EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend in .env first.')
            if not all([settings.EMAIL_HOST, settings.EMAIL_HOST_USER, settings.EMAIL_HOST_PASSWORD]):
                raise CommandError('Complete EMAIL_HOST, EMAIL_HOST_USER and EMAIL_HOST_PASSWORD in .env.')
            try:
                sent = send_mail('CollegeNotice email setup test',
                    'Your CollegeNotice SMTP connection is working. This is a single setup-test message.',
                    settings.DEFAULT_FROM_EMAIL, [recipient], fail_silently=False)
                if sent != 1:
                    raise RuntimeError('Not accepted')
            except Exception:
                raise CommandError('Email failed. Check the Gmail app password, sender address, STARTTLS port 587 and network. No credentials were logged.')
            self.stdout.write(self.style.SUCCESS('Gmail/SMTP accepted the test message. Check your inbox and spam folder.'))

"""Shared error for the local translation service."""


class TranslationError(Exception):
    pass

"""Local, text-only conversation. No cloud calls, tools or runtime downloads."""
import atexit
import json
import logging
import os
from pathlib import Path
import subprocess
import threading
import time
import urllib.error
import urllib.request
from django.conf import settings

logger = logging.getLogger(__name__)
_lock = threading.Lock()
_process = None
_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
URL = 'http://127.0.0.1:18941'
SYSTEM = """You are the CollegeNotice study assistant, a helpful local AI inside a college notice-board app.
Answer general questions, explain concepts, help with coding, writing and study plans. Use the conversation to understand follow-up questions. Be clear, accurate and concise. Use simple Markdown, short paragraphs and examples when helpful. Respond in the user's language when you can.
You have no web browsing, current news, user account access, file access or action tools. Never claim to have searched the internet, changed a notice or performed an action. You cannot see college notices in General chat: for college-specific dates, deadlines or announcements, ask the user to select College notices. Never invent campus facts. State uncertainty when appropriate. Do not present yourself as a human or as ChatGPT. Avoid requesting passwords or secrets."""

class ChatUnavailable(Exception):
    pass

def paths():
    root = Path(settings.LOCAL_CHAT_DIR)
    return root / 'runtime' / 'llama-server.exe', root / 'qwen2.5-3b-instruct-q4_k_m.gguf'

def configured():
    return settings.LOCAL_CHAT_ENABLED and all(path.is_file() for path in paths())

def _request(path, payload=None, timeout=3):
    request = urllib.request.Request(URL + path, data=json.dumps(payload).encode() if payload is not None else None,
                                     headers={'Content-Type': 'application/json'})
    with _opener.open(request, timeout=timeout) as response:
        return json.loads(response.read(1024 * 1024))

def _healthy():
    try:
        return _request('/health').get('status') == 'ok'
    except (OSError, ValueError):
        return False

def _stop():
    if _process is not None and _process.poll() is None:
        _process.terminate()

atexit.register(_stop)

def ensure_running():
    global _process
    if not configured():
        raise ChatUnavailable('General chat is not set up on this computer yet. College notice search is still available.')
    if _healthy():
        return
    with _lock:
        if _healthy():
            return
        executable, model = paths()
        if _process is None or _process.poll() is not None:
            log_path = Path(settings.LOCAL_CHAT_DIR) / 'server.log'
            with log_path.open('ab') as log:
                _process = subprocess.Popen([
                    str(executable), '--model', str(model), '--alias', 'collegenotice-local',
                    '--host', '127.0.0.1', '--port', '18941', '--ctx-size', '4096',
                    '--threads', str(min(6, max(1, (os.cpu_count() or 4) // 2))),
                    '--parallel', '1', '--no-webui', '--no-warmup',
                ], cwd=executable.parent, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            if _healthy():
                return
            if _process.poll() is not None:
                break
            time.sleep(0.4)
        raise ChatUnavailable('The local AI could not start. Please restart CollegeNotice and try again.')

def answer(question, history):
    try:
        ensure_running()
        messages = [{'role': 'system', 'content': SYSTEM}, *history, {'role': 'user', 'content': question}]
        result = _request('/v1/chat/completions', {
            'model': 'collegenotice-local', 'messages': messages, 'stream': False,
            'temperature': 0.4, 'max_tokens': 600,
        }, timeout=180)
        reply = result['choices'][0]['message']['content']
        if not isinstance(reply, str) or not reply.strip():
            raise ValueError('Empty model response')
        return {'reply': reply.strip(), 'sources': [], 'mode': 'Local AI · general chat'}
    except ChatUnavailable:
        raise
    except (OSError, ValueError, KeyError, IndexError, TypeError) as error:
        logger.warning('Local chat unavailable: %s', type(error).__name__)
        raise ChatUnavailable('The local AI is busy or unavailable. Try again in a moment, or use College notices.') from error

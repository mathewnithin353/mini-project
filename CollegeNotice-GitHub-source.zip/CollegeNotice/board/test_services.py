from io import StringIO
from types import SimpleNamespace
from unittest.mock import patch
from django.core.management import call_command, CommandError
from django.test import SimpleTestCase, override_settings
from board.ai import translation_target
from board.serializers import NoticeSerializer


class TranslationTests(SimpleTestCase):
    def test_directions_and_api_label(self):
        for body, target in [('Library opens tomorrow.', 'ml'), ('ലൈബ്രറി തുറക്കും.', 'en')]:
            self.assertEqual(translation_target(body), target)
            self.assertEqual(NoticeSerializer().get_translation_language(SimpleNamespace(body=body)), target)

class ServiceCommandTests(SimpleTestCase):
    def run_check(self, **kwargs):
        output = StringIO()
        call_command('check_services', stdout=output, **kwargs)
        return output.getvalue()

    @patch('board.management.commands.check_services.send_mail')
    @patch('board.management.commands.check_services.analyze')
    def test_default_never_contacts_services(self, analyze_mock, mail):
        self.run_check()
        analyze_mock.assert_not_called()
        mail.assert_not_called()

    @patch('board.management.commands.check_services.translation_configured', return_value=False)
    def test_translation_requires_model(self, ready):
        with self.assertRaisesMessage(CommandError, 'setup-local-translation.bat'):
            self.run_check(test_translation=True)

    @patch('board.management.commands.check_services.translation_configured', return_value=True)
    @patch('board.management.commands.check_services.analyze', return_value={'ai_status': 'local-model', 'translation': 'translated'})
    def test_connection_test_checks_both_directions(self, provider, ready):
        self.assertIn('Both translation requests succeeded', self.run_check(test_translation=True))
        self.assertEqual(provider.call_count, 2)

    def test_demo_address_rejected(self):
        with self.assertRaisesMessage(CommandError, 'Demo .test addresses'):
            self.run_check(email_to='student@college.test')

    @override_settings(EMAIL_BACKEND='django.core.mail.backends.filebased.EmailBackend')
    def test_email_requires_smtp(self):
        with self.assertRaisesMessage(CommandError, 'EMAIL_BACKEND'):
            self.run_check(email_to='student@example.com')

    @override_settings(EMAIL_BACKEND='django.core.mail.backends.smtp.EmailBackend', EMAIL_HOST='smtp.gmail.com',
                       EMAIL_HOST_USER='sender@example.com', EMAIL_HOST_PASSWORD='secret')
    @patch('board.management.commands.check_services.send_mail', return_value=1)
    def test_email_only_sends_to_explicit_recipient_and_redacts_errors(self, mail):
        self.assertIn('accepted', self.run_check(email_to='student@example.com'))
        self.assertEqual(mail.call_args.args[3], ['student@example.com'])
        mail.side_effect = RuntimeError('secret')
        with self.assertRaises(CommandError) as error:
            self.run_check(email_to='student@example.com')
        self.assertNotIn('secret', str(error.exception))

from types import SimpleNamespace
from unittest.mock import patch, MagicMock
from django.test import SimpleTestCase, override_settings
from rest_framework.test import APIRequestFactory, force_authenticate
from board.local_translation import local_translate
from board.translation import TranslationError
from board.views import TranslateText, NoticeViewSet
from board import ai


class LocalTranslationTests(SimpleTestCase):
    def test_invalid_inputs(self):
        for text, target in [('', 'ml'), ('x' * 20001, 'ml'), ('hello', 'fr')]:
            with self.assertRaises(TranslationError):
                local_translate(text, target)

    @patch('board.local_translation.ready', return_value=False)
    def test_missing_model_has_actionable_error(self, ready):
        with self.assertRaisesMessage(TranslationError, 'setup-local-translation.bat'):
            local_translate('Hello', 'ml')

    @patch('board.local_translation._engine')
    def test_same_language_preserved(self, engine):
        self.assertEqual(local_translate('Hello', 'en', 'en'), 'Hello')
        engine.assert_not_called()

    @patch('board.local_translation.ready', return_value=True)
    @patch('board.local_translation._engine')
    def test_both_directions_and_newlines(self, engine, ready):
        tokenizer, translator = MagicMock(), MagicMock()
        tokenizer.encode.return_value = ['token']
        tokenizer.decode.return_value = 'translated'
        translator.translate_batch.return_value = [SimpleNamespace(hypotheses=[['eng_Latn', 'translated']])]
        engine.return_value = tokenizer, translator
        self.assertEqual(local_translate('Hello\n\nWorld', 'ml'), 'translated\n\ntranslated')
        self.assertEqual(translator.translate_batch.call_args.kwargs['target_prefix'], [['mal_Mlym']])
        local_translate('പരീക്ഷ', 'en')
        self.assertEqual(translator.translate_batch.call_args.args[0][0][0], 'mal_Mlym')

    @patch('board.local_translation.ready', return_value=True)
    @patch('board.local_translation._engine')
    def test_long_input_not_truncated(self, engine, ready):
        tokenizer, translator = MagicMock(), MagicMock()
        tokenizer.encode.return_value = [str(i) for i in range(450)]
        tokenizer.decode.return_value = 'translated'
        translator.translate_batch.return_value = [SimpleNamespace(hypotheses=[['mal_Mlym', 'translated']])]
        engine.return_value = tokenizer, translator
        local_translate('Long sentence', 'ml')
        calls = translator.translate_batch.call_args_list
        self.assertEqual(len(calls), 3)
        self.assertEqual(sum(len(c.args[0][0]) - 2 for c in calls), 450)

    @patch('board.local_translation.local_translate', return_value='പരീക്ഷ')
    def test_notice_uses_local_model(self, translate):
        self.assertEqual(ai.analyze('Exam', 'Exam tomorrow')['ai_status'], 'local-model')

    @patch('board.local_translation.local_translate', side_effect=TranslationError('Model missing'))
    def test_notice_failure_keeps_original_analysis(self, translate):
        result = ai.analyze('Exam', 'Exam tomorrow')
        self.assertEqual(result['translation'], '')
        self.assertEqual(result['ai_status'], 'local-model-unavailable')


class TranslateEndpointTests(SimpleTestCase):
    def request(self, payload, authenticated=True):
        request = APIRequestFactory().post('/api/translate/', payload, format='json')
        if authenticated:
            force_authenticate(request, user=SimpleNamespace(is_authenticated=True, pk=123))
        with patch.object(TranslateText, 'throttle_classes', []):
            return TranslateText.as_view()(request)

    def test_requires_login(self):
        self.assertIn(self.request({'text': 'Hello'}, False).status_code, (401, 403))

    @patch('board.local_translation.local_translate', return_value='ഹലോ')
    def test_translation_and_validation(self, translate):
        self.assertEqual(self.request({'text': 'Hello', 'target': 'ml'}).data['translation'], 'ഹലോ')
        for payload in [{'text': ''}, {'text': 'x' * 5001}, {'text': 'Hi', 'target': 'fr'}, {'text': ['Hi']}]:
            self.assertEqual(self.request(payload).status_code, 400)

    @patch('board.local_translation.local_translate', side_effect=TranslationError('Run setup-local-translation.bat'))
    def test_missing_model_returns_service_unavailable(self, translate):
        response = self.request({'text': 'Hello'})
        self.assertEqual(response.status_code, 503)
        self.assertIn('setup-local-translation.bat', response.data['detail'])


class StudentNoticeTranslationTests(SimpleTestCase):
    def request(self, notice, authenticated=True):
        request = APIRequestFactory().post('/api/notices/1/translate/', {}, format='json')
        if authenticated:
            force_authenticate(request, user=SimpleNamespace(is_authenticated=True, pk=123, role='student'))
        with patch.object(NoticeViewSet, 'get_object', return_value=notice) as get_object:
            response = NoticeViewSet.as_view({'post': 'translate'})(request, pk='1')
        return response, get_object

    @patch('board.local_translation.local_translate', return_value='translated')
    def test_student_can_translate_both_directions_without_editing(self, translate):
        for body, target in [('Exam tomorrow', 'ml'), ('പരീക്ഷ', 'en')]:
            notice = SimpleNamespace(body=body, translation='')
            response, get_object = self.request(notice)
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.data['target'], target)
            translate.assert_called_with(body, target)
            get_object.assert_called_once_with()
            self.assertEqual(notice.translation, '')

    @patch('board.local_translation.local_translate')
    def test_existing_translation_reused(self, translate):
        response, _ = self.request(SimpleNamespace(body='Exam', translation='പരീക്ഷ'))
        self.assertEqual(response.data['translation'], 'പരീക്ഷ')
        translate.assert_not_called()

    @patch('board.local_translation.local_translate', side_effect=TranslationError('Model unavailable'))
    def test_model_error_is_readable(self, translate):
        response, _ = self.request(SimpleNamespace(body='Exam', translation=''))
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.data['detail'], 'Model unavailable')

    def test_login_required_before_notice_lookup(self):
        response, get_object = self.request(None, authenticated=False)
        self.assertIn(response.status_code, (401, 403))
        get_object.assert_not_called()

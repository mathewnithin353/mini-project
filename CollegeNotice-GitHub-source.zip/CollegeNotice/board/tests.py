import io
import tempfile
from datetime import timedelta
from unittest.mock import patch
from PIL import Image
from django.conf import settings
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import override_settings
from django.utils import timezone
from rest_framework.test import APITestCase, APIClient
from .ai import analyze, answer, local_analysis
from .models import Activity, Bookmark, Category, Department, EmailDelivery, Notice, Notification, User
from .tasks import archive_expired, create_alerts, process_outbox

@override_settings(CELERY_TASK_ALWAYS_EAGER=True,
                   EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend')
class ProjectTests(APITestCase):
    def setUp(self):
        translation = patch("board.local_translation.local_translate", return_value="Local test translation")
        translation.start()
        self.addCleanup(translation.stop)
        self.media = tempfile.TemporaryDirectory()
        self.override = override_settings(MEDIA_ROOT=self.media.name)
        self.override.enable()
        self.addCleanup(self.media.cleanup)
        self.addCleanup(self.override.disable)
        self.d1 = Department.objects.create(name='MCA')
        self.d2 = Department.objects.create(name='CSE')
        self.category = Category.objects.create(name='Events')
        self.admin = User.objects.create_user('admin@test.local', 'admin@test.local', 'StrongPass@123', role='admin', department=self.d1)
        self.student = User.objects.create_user('student@test.local', 'student@test.local', 'StrongPass@123', department=self.d1)
        self.other = User.objects.create_user('other@test.local', 'other@test.local', 'StrongPass@123', department=self.d2)
        self.coordinator = User.objects.create_superuser('boss@test.local', 'boss@test.local', 'StrongPass@123')
        self.today = timezone.localdate()
        self.notice = Notice.objects.create(title='API seminar', body='Seminar tomorrow. Bring a laptop.', summary='Seminar tomorrow.',
            category=self.category, department=self.d1, created_by=self.admin, expiry_date=self.today+timedelta(days=4))

    def payload(self, **changes):
        return {'title':'Exam deadline', 'body':'Submit by Friday. Bring your college ID.', 'department':self.d1.pk,
                'category':self.category.pk, 'expiry_date':str(self.today+timedelta(days=5)), **changes}

    def auth(self, user=None):
        self.client.force_authenticate(user or self.admin)

    def test_private_api_requires_authentication(self):
        self.assertIn(self.client.get('/api/notices/').status_code, [401,403])

    def test_password_is_hashed(self):
        self.assertNotEqual(self.admin.password,'StrongPass@123')
        self.assertTrue(self.admin.check_password('StrongPass@123'))

    def test_student_cannot_create_or_edit_or_delete(self):
        self.auth(self.student)
        self.assertEqual(self.client.post('/api/notices/',self.payload()).status_code,403)
        self.assertEqual(self.client.patch(f'/api/notices/{self.notice.pk}/',{'title':'Changed'}).status_code,404)
        self.assertEqual(self.client.delete(f'/api/notices/{self.notice.pk}/').status_code,404)

    def test_admin_publish_creates_scoped_alerts(self):
        self.auth()
        with self.captureOnCommitCallbacks(execute=True):
            response=self.client.post('/api/notices/',self.payload(),format='json')
        self.assertEqual(response.status_code,201,response.data)
        n=Notice.objects.get(pk=response.data['id'])
        self.assertTrue(n.priority)
        self.assertTrue(n.summary)
        self.assertTrue(Notification.objects.filter(user=self.student,notice=n).exists())
        self.assertFalse(Notification.objects.filter(user=self.other,notice=n).exists())
        self.assertEqual(EmailDelivery.objects.get(user=self.student,notice=n).status,'demo')
        self.assertTrue(Activity.objects.filter(message__startswith='Published:').exists())

    def test_department_admin_cannot_publish_elsewhere(self):
        self.auth()
        for department in [self.d2.pk, None]:
            self.assertEqual(self.client.post('/api/notices/',self.payload(department=department),format='json').status_code,400)

    def test_cross_department_edit_is_blocked(self):
        other=Notice.objects.create(title='Other',body='Body',category=self.category,department=self.d2,created_by=self.admin,expiry_date=self.today)
        self.auth()
        self.assertEqual(self.client.patch(f'/api/notices/{other.pk}/',{'title':'Bad'}).status_code,404)

    def test_coordinator_campus_notice_alerts_all(self):
        self.auth(self.coordinator)
        response=self.client.post('/api/notices/',self.payload(department=None),format='json')
        self.assertEqual(response.status_code,201,response.data)
        self.assertEqual(Notification.objects.filter(notice_id=response.data['id']).count(),2)

    def test_bad_dates_and_unknown_catalog_rejected(self):
        self.auth()
        for changes in [{'expiry_date':'not-a-date'},{'expiry_date':str(self.today-timedelta(days=1))},
                        {'publish_date':str(self.today+timedelta(days=1))},{'category':9999},{'title':''}]:
            self.assertEqual(self.client.post('/api/notices/',self.payload(**changes),format='json').status_code,400)

    def test_expired_hidden_before_scheduled_sweep(self):
        self.notice.publish_date=self.today-timedelta(days=5)
        self.notice.expiry_date=self.today-timedelta(days=1)
        self.notice.save()
        self.auth(self.student)
        self.assertEqual(self.client.get('/api/notices/').data['count'],0)
        self.assertEqual(self.client.get(f'/api/notices/{self.notice.pk}/').status_code,404)
        self.assertEqual(archive_expired(),1)
        self.notice.refresh_from_db();self.assertTrue(self.notice.archived)

    def test_admin_can_archive_and_restore(self):
        self.auth()
        self.assertEqual(self.client.patch(f'/api/notices/{self.notice.pk}/',{'archived':True},format='json').status_code,200)
        self.assertEqual(self.client.get('/api/notices/?state=archived').data['count'],1)
        self.assertEqual(self.client.patch(f'/api/notices/{self.notice.pk}/',{'archived':False},format='json').status_code,200)
        self.assertEqual(self.client.get('/api/notices/').data['count'],1)

    def test_student_cannot_retrieve_archive(self):
        self.notice.archived=True;self.notice.save()
        self.auth(self.student)
        self.assertEqual(self.client.get('/api/notices/?state=archived').data['count'],0)

    def test_filters_search_date_category_department(self):
        self.auth(self.student)
        query=f'?q=seminar&department={self.d1.pk}&category={self.category.pk}&from={self.today}&to={self.today}'
        self.assertEqual(self.client.get('/api/notices/'+query).data['count'],1)
        self.assertEqual(self.client.get('/api/notices/?q=unmatched').data['count'],0)
        self.assertEqual(self.client.get('/api/notices/?department=bad').status_code,400)
        self.assertEqual(self.client.get('/api/notices/?from=bad').status_code,400)
        self.assertEqual(self.client.get(f'/api/notices/?from={self.today}&to={self.today-timedelta(days=1)}').status_code,400)
        self.notice.title = 'Project review seminar'
        self.notice.save(update_fields=['title'])
        self.assertEqual(self.client.get('/api/notices/?q=review%20project').data['count'],1)
        self.assertEqual(self.client.get('/api/notices/?q=review%20missingword').data['count'],0)

    def test_bookmarks_are_unique_and_user_scoped(self):
        self.auth(self.student)
        for _ in range(2): self.assertEqual(self.client.post(f'/api/notices/{self.notice.pk}/bookmark/').status_code,200)
        self.assertEqual(Bookmark.objects.count(),1)
        self.assertEqual(self.client.get('/api/notices/?saved=1').data['count'],1)
        self.auth(self.other)
        self.assertEqual(self.client.get('/api/notices/?saved=1').data['count'],0)

    def test_unbookmark(self):
        Bookmark.objects.create(user=self.student,notice=self.notice)
        self.auth(self.student)
        self.client.delete(f'/api/notices/{self.notice.pk}/bookmark/')
        self.assertFalse(Bookmark.objects.exists())

    def test_notifications_idempotent_and_read_scoped(self):
        create_alerts(self.notice);create_alerts(self.notice)
        self.assertEqual(Notification.objects.count(),1)
        self.auth(self.other)
        self.client.post('/api/notifications/',{'id':Notification.objects.first().pk},format='json')
        self.assertFalse(Notification.objects.first().is_read)
        self.auth(self.student);self.client.post('/api/notifications/',{},format='json')
        self.assertEqual(self.client.get('/api/notifications/').data['unread'],0)

    def test_email_opt_out(self):
        self.student.email_alerts=False;self.student.save();create_alerts(self.notice)
        self.assertFalse(EmailDelivery.objects.exists())
        self.assertTrue(Notification.objects.exists())

    def test_email_failure_is_retryable(self):
        create_alerts(self.notice)
        with patch('board.tasks.send_mail',side_effect=OSError('offline')): process_outbox()
        row=EmailDelivery.objects.get();self.assertEqual(row.status,'failed');self.assertEqual(row.attempts,1)
        process_outbox();row.refresh_from_db();self.assertEqual(row.status,'demo');self.assertEqual(row.attempts,2)

    def test_demo_email_is_not_claimed_sent(self):
        create_alerts(self.notice);process_outbox();process_outbox()
        row=EmailDelivery.objects.get();self.assertEqual(row.status,'demo');self.assertIsNone(row.sent_at);self.assertEqual(row.attempts,1)

    def test_expired_email_is_skipped(self):
        create_alerts(self.notice);self.notice.archived=True;self.notice.save();process_outbox()
        self.assertEqual(EmailDelivery.objects.get().status,'skipped')

    def test_real_smtp_status_with_mock_backend(self):
        create_alerts(self.notice)
        with override_settings(EMAIL_BACKEND='django.core.mail.backends.smtp.EmailBackend'),patch('board.tasks.send_mail',return_value=1):process_outbox()
        self.assertEqual(EmailDelivery.objects.get().status,'sent')

    def test_attachments_validate_contents_and_size(self):
        self.auth()
        for name,content in [('bad.html',b'<script>'),('bad.pdf',b'fake'),('bad.png',b'not an image'),('large.pdf',b'%PDF-'+b'x'*(5*1024*1024))]:
            self.assertEqual(self.client.post('/api/notices/',self.payload(attachment=SimpleUploadedFile(name,content)),format='multipart').status_code,400)

    def test_valid_image_download_and_replacement(self):
        self.auth();buf=io.BytesIO();Image.new('RGB',(4,4)).save(buf,format='PNG')
        r=self.client.post('/api/notices/',self.payload(attachment=SimpleUploadedFile('map.png',buf.getvalue())),format='multipart')
        self.assertEqual(r.status_code,201,r.data)
        url=r.data['attachment_url'];self.assertTrue(url)
        response=self.client.get(url);self.assertEqual(response.status_code,200);response.close()
        self.client.force_authenticate(None);self.assertIn(self.client.get(url).status_code,[401,403])
        self.auth();self.client.patch(f"/api/notices/{r.data['id']}/",{'clear_attachment':True},format='json')
        self.assertEqual(self.client.get(url).status_code,404)

    def test_image_preview_and_download_keep_original_bytes(self):
        for image_format, name, mime in [('PNG', 'map.png', 'image/png'),
                                         ('JPEG', 'photo.jpg', 'image/jpeg'),
                                         ('PNG', 'misnamed.jpeg', 'image/png')]:
            with self.subTest(name=name):
                buf = io.BytesIO()
                Image.new('RGB', (20, 10), 'green').save(buf, format=image_format)
                self.auth()
                created = self.client.post('/api/notices/', self.payload(
                    attachment=SimpleUploadedFile(name, buf.getvalue())), format='multipart')
                self.assertEqual(created.status_code, 201, created.data)
                self.auth(self.student)
                url = created.data['attachment_url']
                for query, disposition in [('?preview=1', 'inline'), ('', 'attachment')]:
                    response = self.client.get(url + query)
                    self.assertEqual(response.status_code, 200)
                    self.assertTrue(response['Content-Disposition'].startswith(disposition + ';'))
                    self.assertEqual(response['Cache-Control'], 'private, no-store')
                    self.assertEqual(response['X-Content-Type-Options'], 'nosniff')
                    if query:
                        self.assertEqual(response['Content-Type'], mime)
                    self.assertEqual(b''.join(response.streaming_content), buf.getvalue())
                    response.close()

    def test_image_preview_retains_authentication_and_archive_permissions(self):
        self.auth()
        buf = io.BytesIO()
        Image.new('RGB', (4, 4)).save(buf, format='PNG')
        created = self.client.post('/api/notices/', self.payload(
            attachment=SimpleUploadedFile('map.png', buf.getvalue())), format='multipart')
        url = created.data['attachment_url'] + '?preview=1'
        self.client.force_authenticate(None)
        self.assertIn(self.client.get(url).status_code, [401, 403])
        notice = Notice.objects.get(pk=created.data['id'])
        notice.archived = True
        notice.save()
        self.auth(self.student)
        self.assertEqual(self.client.get(url).status_code, 404)
        self.assertEqual(self.client.get(url + '&state=archived').status_code, 404)
        self.auth()
        response = self.client.get(url + '&state=archived')
        self.assertEqual(response.status_code, 200)
        response.close()

    def test_pdf_remains_download_only_and_missing_file_returns_404(self):
        self.auth()
        created = self.client.post('/api/notices/', self.payload(
            attachment=SimpleUploadedFile('notice.pdf', b'%PDF-1.4\n%%EOF')), format='multipart')
        self.assertEqual(created.status_code, 201, created.data)
        url = created.data['attachment_url']
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response['Content-Disposition'].startswith('attachment;'))
        response.close()
        self.assertEqual(self.client.get(url + '?preview=1').status_code, 400)
        notice = Notice.objects.get(pk=created.data['id'])
        notice.attachment.storage.delete(notice.attachment.name)
        self.assertEqual(self.client.get(url + '?preview=1').status_code, 404)

    def test_delete_cascades_related_data(self):
        create_alerts(self.notice);Bookmark.objects.create(user=self.student,notice=self.notice)
        self.auth();self.assertEqual(self.client.delete(f'/api/notices/{self.notice.pk}/').status_code,204)
        self.assertFalse(Notification.objects.exists());self.assertFalse(Bookmark.objects.exists());self.assertFalse(EmailDelivery.objects.exists())

    def test_catalog_permissions_and_protected_deletion(self):
        self.auth(self.student);self.assertEqual(self.client.post('/api/categories/',{'name':'New'}).status_code,403)
        self.auth();self.assertEqual(self.client.post('/api/categories/',{'name':'New'}).status_code,201)
        self.assertEqual(self.client.delete(f'/api/categories/{self.category.pk}/').status_code,400)

    def test_profile_cannot_escalate_role(self):
        self.auth(self.student)
        self.client.patch('/api/profile/',{'name':'Student Name','role':'admin','is_superuser':True,'department':self.d2.pk},format='json')
        self.student.refresh_from_db();self.assertEqual(self.student.role,'student');self.assertFalse(self.student.is_superuser);self.assertEqual(self.student.department,self.d1)

    def test_registration_never_creates_admin(self):
        r=self.client.post('/api/auth/register/',{'name':'New Student','email':'new@example.test','password':'UnusualStrong!451','department':self.d1.pk,'role':'admin'},format='json')
        self.assertEqual(r.status_code,201,r.data);self.assertEqual(User.objects.get(email='new@example.test').role,'student')

    def test_password_change_requires_current(self):
        self.auth(self.student)
        self.assertEqual(self.client.post('/api/password/',{'current_password':'bad','new_password':'NewStrong!421'},format='json').status_code,400)
        self.assertEqual(self.client.post('/api/password/',{'current_password':'StrongPass@123','new_password':'NewStrong!421'},format='json').status_code,200)

    def test_login_csrf_enforced(self):
        browser=APIClient(enforce_csrf_checks=True)
        self.assertEqual(browser.post('/api/auth/login/',{'email':self.student.email,'password':'StrongPass@123'},format='json').status_code,403)
        browser.get('/');csrf=browser.cookies['csrftoken'].value
        r=browser.post('/api/auth/login/',{'email':self.student.email,'password':'StrongPass@123'},format='json',HTTP_X_CSRFTOKEN=csrf)
        self.assertEqual(r.status_code,200,r.data)
        self.assertEqual(browser.get('/api/notices/').status_code,200)

    def test_jwt_login_and_protected_api(self):
        r=self.client.post('/api/auth/token/',{'username':self.student.username,'password':'StrongPass@123'},format='json')
        self.assertEqual(r.status_code,200,r.data)
        self.client.credentials(HTTP_AUTHORIZATION='Bearer '+r.data['access'])
        self.assertEqual(self.client.get('/api/notices/').status_code,200)

    def test_chat_links_to_active_sources_only(self):
        self.auth(self.student)
        r=self.client.post('/api/chat/',{'question':'API seminar'},format='json')
        self.assertEqual(r.status_code,200);self.assertEqual(r.data['sources'][0]['id'],self.notice.pk)
        self.notice.archived=True;self.notice.save()
        r=self.client.post('/api/chat/',{'question':'API seminar'},format='json');self.assertEqual(r.data['sources'],[])

    def test_malayalam_local_mode_does_not_fake_translation(self):
        r=local_analysis('അറിയിപ്പ്','പരീക്ഷ അടുത്ത ആഴ്ച നടക്കും.')
        self.assertEqual(r['translation'],'');self.assertEqual(r['ai_status'],'local-translation-needed');self.assertTrue(r['priority'])

    def test_export_neutralizes_spreadsheet_formulas(self):
        self.notice.title='=HYPERLINK("bad")';self.notice.save();self.auth()
        response=self.client.get('/api/export/');self.assertEqual(response.status_code,200)
        self.assertIn("'=HYPERLINK",response.content.decode())

    def test_dashboard_is_admin_only(self):
        self.auth(self.student);self.assertEqual(self.client.get('/api/dashboard/').status_code,403)
        self.auth();r=self.client.get('/api/dashboard/');self.assertEqual(r.status_code,200);self.assertEqual(r.data['active'],1)

    def test_summary_preserves_time_and_venue(self):
        result=local_analysis('Seminar', 'Meet at 2:00 p.m. in Seminar Hall A. Bring a laptop.')
        self.assertIn('2:00 p.m. in Seminar Hall A.',result['summary'])

    def test_priority_detects_report_submission_deadline(self):
        self.assertTrue(local_analysis('Review', 'Submit your report by 12 October.')['priority'])

@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run start.bat once to create the project Python environment, then close the server.
  pause
  exit /b 1
)
echo Installing the local translation runtime...
".venv\Scripts\python.exe" -m pip install -r requirements-local.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" manage.py setup_local_translation
if errorlevel 1 goto failed
".venv\Scripts\python.exe" manage.py check_services --test-translation
if errorlevel 1 goto failed
echo Ready. Restart CollegeNotice with start.bat.
pause
exit /b 0
:failed
echo Setup did not complete. Check the error above and retry.
pause
exit /b 1

# Sharing and installing CollegeNotice

This is the source-code edition of the supplied CollegeNotice.zip.
The working folder and original ZIP have not been modified.

## GitHub
Extract this ZIP and upload the CONTENTS of the CollegeNotice folder to your
repository. Include .gitignore and .env.example. Keep .env private.
GitHub Desktop can include hidden files and upload all source files together.

## Google Drive
Upload this small ZIP for source-code submission. The recipient installs
Python dependencies and downloads models using the supplied setup scripts.
The source ZIP is not a ready-to-run offline installation.

## First run on another computer
1. Extract the archive completely; install Python 3.12.
2. Run start.bat to install dependencies and initialize the demo database.
   Open the local URL printed in the terminal and keep that terminal open.
3. Run setup-local-translation.bat for the English/Malayalam model.
4. Run setup-local-chat.bat for the general-chat model, if wanted.
5. Restart start.bat. Initial package/model installation requires internet.
6. Configure Gmail privately in .env if email delivery is required.
   Use .env.example for the variable names; do not publish credentials.

## Omitted from this package
- local-models: downloaded translation/chat models and runtime binaries
- .venv: installed Python environment (recreated by the launcher)
- .env: private local settings and credentials
- db.sqlite3: local accounts, notices and other database records
- media and demo-emails: local uploads and generated email output
- staticfiles, Python caches and logs: generated files

All application source, database migrations, source static assets, templates,
documentation, dependency manifests and setup scripts are retained.
Existing personal notices and uploaded attachments are not included.
Keep the original privately if you need a backup of local data and models.

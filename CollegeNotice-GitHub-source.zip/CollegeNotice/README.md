# CollegeNotice

A college mini project rebuilt around the supplied Digital Notice Board presentation: Django, Django REST Framework, PostgreSQL, Celery/Redis, a responsive PWA and local English–Malayalam translation.

## Start here on Windows

1. Extract the ZIP completely.
2. Install Python 3.12 if it is not already installed.
3. Double-click **start.bat** inside the CollegeNotice folder.
4. Wait for setup and the browser to open **http://127.0.0.1:8000**. The first run requires internet access to install dependencies.
5. Keep the terminal window open while using the project. Press Ctrl+C to stop it.

The launcher creates an isolated `.venv`, installs dependencies, applies database migrations and creates fictional demonstration accounts. It does not replace existing notices or reset existing passwords.

### Demo accounts

All these demo accounts initially use **College@12345**.

| Account | Email | Permissions |
|---|---|---|
| Student | student@college.test | Browse, search, save, read alerts, ask the assistant |
| MCA department admin | admin@college.test | Manage Computer Applications notices and view its dashboard |
| CSE department admin | cse.admin@college.test | Manage Computer Science notices |
| CSE student | cse.student@college.test | Demonstrate department-specific alerts |
| Campus coordinator | coordinator@college.test | Campus-wide notices, all departments and Django user administration |

The `.test` addresses are intentionally non-deliverable. These are demonstration identities, not real college accounts. Turn off demo mode and create real users before deploying for a college.

## Two supported configurations

| | Easy local demo | Presentation stack |
|---|---|---|
| Backend | Django + DRF | Django + DRF |
| Database | SQLite | PostgreSQL |
| Tasks | Immediate execution | Celery worker + Redis + Celery beat |
| Email default | Local demo files | Local demo files; SMTP can be configured |
| AI default | Local extractive summary, rules and notice search | Local NLP; install the local translation model separately |
| Start | start.bat / python launcher.py | Docker Compose |

**The easy launch does not run PostgreSQL or Redis.** Use the Docker configuration when demonstrating the exact stack from the slides. Both configurations use the same models, API, permission checks and interface.

## Run the complete Django/PostgreSQL/Celery stack

Prerequisite: Docker with Docker Compose, such as Docker Desktop running Linux containers.

```powershell
Copy-Item .env.example .env
docker compose up --build
```

Open **http://localhost:8000**. The `setup` container waits for PostgreSQL and Redis, then runs migrations and optional demo seeding. The web, worker and scheduler containers start only after setup succeeds. Database and uploaded files use named persistent volumes.

```powershell
# Stop containers while preserving database and files
docker compose down

# Run the test suite against PostgreSQL
docker compose exec web python manage.py test board

# Inspect background jobs
docker compose logs worker beat
```

Do not use `docker compose down -v` unless you intend to delete the database and uploaded files.

Docker was not available on the review computer, so PostgreSQL and distributed Celery execution are **configured but not integration-tested there**. See `docs/VALIDATION.md` for exact verification coverage.

For step-by-step translation and Gmail activation, read [Translation and Gmail setup](docs/TRANSLATION_AND_GMAIL_SETUP.md).

## Free local translation (current setup)

English ↔ Malayalam now runs locally without a paid API. Follow [Local translation setup](docs/LOCAL_TRANSLATION_SETUP.md): run `setup-local-translation.bat` once to install the runtime and download about 630 MB of model data, then restart. Use **Translate text** in the sidebar for words or sentences; new/edited notices translate automatically. Gmail remains independent. Model data is excluded from the ZIP.

## General-topic AI assistant (Windows local setup)

Open **AI assistant → General chat** for explanations, coding help, writing and study plans. Follow-up questions use the recent conversation. **New chat** or switching modes clears that conversation. **College notices** keeps the source-based search for active announcements; it works even if the general model is unavailable.

Run `setup-local-chat.bat` once if the model is not installed. It downloads a portable Windows CPU runtime and the approximately 2.1 GB Qwen2.5-3B-Instruct Q4_K_M model into `local-models/chat/`, verifies their SHA-256 checksums, and resumes interrupted downloads. There is no API key or usage fee. The model and runtime are excluded from source packages by `local-models/`.

Restart with `start.bat`. The model starts automatically on the first general-chat request, which can take longer. It listens only on `127.0.0.1:18941`; keep this port free. Chat requests do not download models or contact cloud services. Only recent messages from the current browser session are sent to the local model. Messages are not saved as conversation records in the database. The local runtime stops with the Django process that started it.

General chat has no live web access, cannot change notices, and does not read college announcements. Use College notices for campus dates and official information. The small local model can make mistakes and is less capable than large hosted assistants. English works best; the existing Malayalam translation button remains available. Use `LOCAL_CHAT_ENABLED=0` to disable general chat. This bundled runtime is for Windows x64; the Docker configuration does not start it.

Upstream: [llama.cpp server](https://github.com/ggml-org/llama.cpp/tree/master/tools/server), [official Qwen model](https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF).

## Enable real email

By default, messages are saved under `demo-emails/` and the dashboard labels them **demo**, never **sent**. To send real email, configure your own mail provider:

```dotenv
EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=your.smtp.host
EMAIL_PORT=587
EMAIL_HOST_USER=your_username
EMAIL_HOST_PASSWORD=your_app_password
EMAIL_USE_TLS=1
DEFAULT_FROM_EMAIL=CollegeNotice <your_verified_sender@your-college-domain>
```

Use real recipient accounts and restart the services. Publish a new notice to test delivery. Previously generated demo messages are deliberately not converted into real outgoing mail. Students can opt out of email in their profile. “Sent” means the SMTP server accepted a message; inbox arrival is not guaranteed.

In Docker mode, the worker processes queued mail and the scheduler retries failures once per minute, up to three attempts. The dashboard allows an administrator to retry failed jobs. In local demo mode, publishing runs the task immediately; run `python manage.py maintenance` for a manual archive/outbox sweep.

## Main features

- Student self-registration, secure session login, password changes and profile preferences.
- Standard JWT access/refresh/revocation endpoints for API clients. Browser UI uses CSRF-protected sessions instead of exposing tokens to JavaScript storage.
- Server-enforced department permissions. Campus-wide publishing is reserved for a superuser coordinator.
- Notice create, edit, delete, category/department tagging, expiry, manual archive and restore.
- PDF/PNG/JPEG attachments, 5 MB limit, content checks and authenticated download.
- Keyword, department, category, publication date, priority and saved-notice filters; paginated results.
- Unique per-user bookmarks, department/campus notifications and unread counts.
- In-app notifications refresh every 10 seconds: **near-real-time polling**, not WebSocket push.
- Extractive NLP summaries, urgency detection, local English–Malayalam translation and grounded chat with source links.
- Department dashboard, category chart, activity log, email status and CSV report export.
- Responsive interface, PWA manifest and icons, offline fallback page. Private notices are not cached for offline reading.

## Manual setup / development

### VS Code on Windows

Open the **CollegeNotice** folder itself in VS Code. Run `start.bat` once to install the dependencies into `.venv`. Then press **Ctrl+Shift+P**, choose **Python: Select Interpreter**, and select `.venv\Scripts\python.exe`. If it is not listed, choose **Enter interpreter path** and browse to that file. Open a new terminal after changing the interpreter.

To avoid interpreter-selection problems, run this explicit command from the project folder:

```powershell
.\.venv\Scripts\python.exe manage.py runserver
```

The supplied VS Code configuration also provides **CollegeNotice: Django** under Run and Debug. Do not run `config/celery.py` directly. If `ModuleNotFoundError: No module named 'celery'` appears, the chosen Python environment does not have the project dependencies; using the project's `.venv` resolves that mismatch.

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python manage.py migrate
.venv\Scripts\python manage.py seed_demo
.venv\Scripts\python manage.py runserver
```

On macOS/Linux, use `.venv/bin/python` instead. `requirements-lock.txt` records the full dependency set tested on Windows/Python 3.12; `requirements.txt` pins direct dependencies and lets pip resolve platform-specific wheels.

```powershell
.venv\Scripts\python manage.py test board
.venv\Scripts\python manage.py check
.venv\Scripts\python manage.py makemigrations --check --dry-run
```

No Node.js build or frontend package installation is required.

## Project structure

```text
config/                 Django settings, URLs, WSGI and Celery setup
board/models.py         Relational data model
board/serializers.py    Validation, uploads and role rules
board/views.py          REST API and application workflows
board/ai.py             Local NLP + local translation
board/tasks.py          Persistent email outbox and automatic archival
board/tests.py          Automated behaviour and permission tests
board/migrations/       Reproducible database schema
templates/index.html    Application shell
static/                 Responsive UI, JavaScript, PWA and offline page
docs/                   Review, architecture, demo guide and validation
compose.yaml            PostgreSQL, Redis, Django, worker and scheduler
```

## Before any public deployment

The supplied Docker port is bound to loopback for a local demonstration. Public hosting requires a domain, HTTPS reverse proxy, `DEBUG=0`, `DEMO_MODE=0`, a new long random `SECRET_KEY`, correct hosts/origins, database backups and removal of demo accounts. Configure proxy HTTPS handling for your deployment. Do not expose PostgreSQL or Redis publicly. Use `python manage.py check --deploy` against the production settings. This package has not been deployed to AWS/Railway, and it does not claim cloud storage or encryption at rest.

Keep `.env`, uploaded files and databases out of source control. For an institution-wide deployment, add verified/approved registration, password recovery, malware scanning, central monitoring and load testing. Those are beyond the verified mini-project scope.

## Troubleshooting

- **Translate text menu missing after an update:** run `.\.venv\Scripts\python.exe manage.py collectstatic --noinput`, then refresh the browser. The running site may otherwise serve older collected JavaScript. `start.bat` performs this step automatically.

- **Python not found:** install Python 3.12 and reopen the launcher.
- **Port 8000 in use:** stop the other server or set `PORT=8001` before running `launcher.py`.
- **No notices after many days:** the seeded notices intentionally expire. Publish new notices; seed_demo will not overwrite existing work.
- **No translation:** run setup-local-translation.bat, restart, then click the notice translation button.
- **Email shows demo:** this is expected until an SMTP backend is configured.
- **Docker refuses to start:** copy `.env.example` to `.env`, confirm Docker is running, then inspect `docker compose logs`.
- **PWA install missing:** installation depends on browser support and requires HTTPS or localhost. The ordinary website still works.
- **Login stopped after changing the secret:** sign in again; changing the secret invalidates existing sessions/tokens.

Read `docs/REQUIREMENTS_REVIEW.md` first for the comparison with the supplied project, and `docs/DEMO_GUIDE.md` for the viva demonstration.

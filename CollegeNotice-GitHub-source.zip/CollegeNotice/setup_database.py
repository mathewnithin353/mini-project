import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
import django
django.setup()
from django.conf import settings
from django.core.management import call_command

call_command('migrate', interactive=False)
if settings.DEMO_MODE:
    call_command('seed_demo')

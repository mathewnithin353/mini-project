# Local English ↔ Malayalam translation

The project uses local translation only. It translates words, sentences and notices on the Django computer using Meta's NLLB-200 distilled 600M model, with an int8 CTranslate2 runtime. No API key, paid account or translation network connection is used after setup. Gmail still needs internet to send email.

## First setup on another computer

1. Extract the project and run `start.bat` once to install the standard project dependencies. Stop the server.
2. Double-click `setup-local-translation.bat`. It installs the small translation runtime and downloads approximately 630 MB of model data. Leave it open until both translation tests succeed.
3. Run `start.bat` again and sign in.
4. Sign in as a student and open a notice. Press **Translate to Malayalam** or **Translate to English** below its original text. For separate text, select **Translate text** in the student sidebar.

The ZIP excludes model data and credentials. Setup must be run once on each new computer, or copy the complete `local-models/nllb-600m-int8` directory from your configured computer. Model downloads are explicit: a normal translation request will never download anything.

Manual commands, from the CollegeNotice folder:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-local.txt
.\.venv\Scripts\python.exe manage.py setup_local_translation
.\.venv\Scripts\python.exe manage.py check_services --test-translation
.\.venv\Scripts\python.exe manage.py runserver
```

On Windows, CTranslate2 requires Microsoft's Visual C++ runtime. If the model cannot load and a DLL is missing, install the official runtime linked from the [CTranslate2 installation guide](https://opennmt.net/CTranslate2/installation.html).

## Notices and the translation page

Students can translate any accessible notice directly in its reading dialog, without administrator edits. The button reuses a stored translation when available and otherwise translates locally on demand. Reading a translation does not change the notice or send email alerts. Summaries, priority detection and the notice assistant remain local; no external translation service is used.

The Translate text page accepts up to 5,000 characters and requires login. Notice bodies support up to 20,000 characters. Long input is split into sentences and smaller token chunks rather than silently truncated. Paragraph breaks are preserved. English and Malayalam are the supported interface languages; this is not a promise to translate every language.

The first request loads the model and can take longer. CPU translation speed depends on hardware and text length. Keep the Django server running; local translation does not mean the browser works without its server. Requests share one model per process, and translation runs serially to limit memory consumption. Use a single web worker for a small demo if RAM is limited.

## Accuracy and license

Review results against the original, especially names, dates, abbreviations, technical vocabulary, mixed languages and isolated words. This is machine translation, not a dictionary with all meanings or transliteration. Sentence context generally helps. The local summary copies source sentences and does not become a generative English summary of Malayalam input.

Model: [Meta NLLB-200 distilled 600M](https://huggingface.co/facebook/nllb-200-distilled-600M), licensed **CC-BY-NC-4.0**, for non-commercial research/educational use; the publisher does not release it for production deployment. This project uses the [JustFrederik CTranslate2 int8 conversion](https://huggingface.co/JustFrederik/nllb-200-distilled-600M-ct2-int8), pinned to revision `302d78f00e6fdb50a1064059df7c392b735e9d05`. The download command checks SHA-256 hashes for the model and tokenizer. It downloads data files only and executes no code from the model repository.

## Docker

The existing base Docker image does not install optional translation dependencies. To use local translation there, install `requirements-local.txt` in the image, and mount the downloaded model directory at `/app/local-models/nllb-600m-int8` in the web service. Do not embed model data in the normal source ZIP. The ordinary Windows setup is the supported local demo path.

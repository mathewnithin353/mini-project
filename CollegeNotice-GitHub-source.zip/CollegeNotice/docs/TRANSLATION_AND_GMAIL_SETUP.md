# Local English ↔ Malayalam translation and Gmail setup

Translation uses the local model without API keys. Follow [Local translation setup](LOCAL_TRANSLATION_SETUP.md). Gmail needs your sender account and app password.

## 2. Configure Gmail

Enable Google account **2-Step Verification**, then create a [Google app password](https://support.google.com/accounts/answer/185833). Use the generated app password, not your ordinary Gmail password. Some managed or restricted Google accounts do not offer app passwords; ask the account administrator if the option is unavailable.

Set these values in the same `.env` file:

```dotenv
EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_HOST_USER=youraddress@gmail.com
EMAIL_HOST_PASSWORD=your_16_character_app_password_without_spaces
EMAIL_USE_TLS=1
DEFAULT_FROM_EMAIL=CollegeNotice <youraddress@gmail.com>
```

Replace both occurrences of the sender address with your Gmail address. Google documents these SMTP settings in its [Gmail configuration guide](https://support.google.com/mail/answer/7104828?hl=en).

## 3. Restart and check

Stop the running server with Ctrl+C. From the CollegeNotice folder in VS Code's PowerShell terminal:

```powershell
.\.venv\Scripts\python.exe manage.py check_services
.\.venv\Scripts\python.exe manage.py runserver
```

The first command checks configuration only. It does not send mail or make API calls. In another terminal you can explicitly test the services:

```powershell
# Tests two short samples using the local model.
.\.venv\Scripts\python.exe manage.py check_services --test-translation

# Replace the address with your own inbox. Sends exactly one test email.
.\.venv\Scripts\python.exe manage.py check_services --email-to youraddress@gmail.com
```

For Docker, recreate services after editing `.env`: `docker compose up -d --force-recreate web worker beat`. Run the same management commands with `docker compose exec web python manage.py` instead of the Windows Python path.

## 4. Demonstrate it

1. Register a student using a real email address. Keep email alerts enabled in the student's profile.
2. Deactivate the fictional `.test` student accounts in Django administration before using real SMTP. Those addresses cannot receive messages.
3. Log in as an administrator and publish a new notice for that student's department, or use the coordinator for a campus-wide notice.
4. Open the notice to view the translation. Check the student's inbox and spam folder for the alert.
5. Publish a Malayalam notice to demonstrate the English translation.

Email recipients must be active students with alerts enabled and match the notice's department (campus notices reach all departments). Previously generated demo email records are not resent through Gmail. Editing an existing notice regenerates its translation but should not be used as a new-email test; publish a new notice for that test.

The dashboard's “sent” status means SMTP accepted the message, not guaranteed inbox delivery. Failed messages can be retried from the dashboard; the Celery scheduler retries in the full stack. Local mode runs sending immediately. Gmail account sending limits still apply, so this setup is intended for a small demonstration.

## Troubleshooting

- Missing `celery`: run `start.bat` to install dependencies and select `.venv\Scripts\python.exe` in VS Code.
- Translation unavailable: run setup-local-translation.bat and restart the server.
- Email marked demo: select the SMTP backend in `.env` and restart all services.
- Gmail authentication failure: check the app password and account address; do not substitute your normal Google password.
- No email: test your own inbox first, then check student preferences, department, expiry date and dashboard status.

The downloadable ZIP excludes `.env` and your local database. Configure credentials separately after extracting it elsewhere.

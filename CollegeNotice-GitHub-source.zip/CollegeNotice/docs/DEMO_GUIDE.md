# College review demonstration and viva guide

## Before the review

Start the project once while connected to the internet so dependencies finish installing. Use the README's demo accounts. Run the test suite. Keep this guide and the requirement review available.

If you intend to claim the exact presentation stack in the demonstration, launch Docker Compose and check the PostgreSQL, Redis, worker and beat containers. If you use the easy launcher, explicitly say it is the SQLite demo profile of the same Django application.

Test Gmail SMTP separately and run `manage.py check_services --test-translation` before the demo. Translation runs locally without API keys.

## Suggested 8-minute demonstration

| Time | Action | What it demonstrates |
|---|---|---|
| 0:00–0:45 | Sign in as `student@college.test`; show the board on a desktop and narrow window | Authentication, responsive interface, priority labels |
| 0:45–1:30 | Filter Computer Applications + Examinations; search “DBMS”; reset filters | Server-side filtering and search |
| 1:30–2:15 | Open a notice, compare summary with original, save it and visit Saved notices | Readable summaries and persistent bookmarks |
| 2:15–3:00 | Ask the assistant “Which notices are urgent?” and open a returned source | Search/AI assistance with source traceability |
| 3:00–4:30 | In a separate browser profile/incognito session, sign in as admin; publish a notice with a category, expiry and PDF | CRUD, validation, private attachments, alerts |
| 4:30–5:15 | Return to the student session; allow up to ten seconds; open Notifications | Near-real-time departmental alerts and unread state |
| 5:15–6:00 | Show the admin dashboard, category chart, activity and email status; export CSV | Administrator control and reports |
| 6:00–6:45 | Archive the demo notice and refresh the student board; restore it from Archive | Lifecycle and role enforcement |
| 6:45–7:30 | Open a notice as a student and click Translate; demonstrate Assistant answer translation too | Local English–Malayalam support |
| 7:30–8:00 | Show test results and architecture diagram; explain current limitations | Engineering evidence and honest scope |

Two tabs in the same browser share cookies. Use an incognito window or another browser to keep a student and admin signed in simultaneously.

## Example notice to enter

Title: **Mini-project demonstration schedule**

Body: **The MCA mini-project demonstration will be held on [choose a future date] at 10:00 a.m. in Seminar Hall A. Bring the working application, source code and report. Submit your report by [choose a deadline].**

Choose Academic, your own department and a future expiry date. Replace bracketed dates before publishing. Attach a small non-sensitive PDF you are happy to use for the demonstration.

## Questions you should be ready to answer

**Why Django and DRF?** Django supplies the ORM, migrations, password hashing and administration. DRF supplies serializers, validation, permissions, throttling and REST endpoints.

**How are roles enforced?** The backend checks each write. Department admins can manage their department's notices. A superuser coordinator can publish campus-wide. Hiding a UI button is not the security boundary.

**What is the difference between expiry and archival?** Expiry is date-based visibility. Every active query checks the date, so a delayed scheduler cannot expose expired content. The scheduler persists the archived flag; an administrator can also archive early.

**Why use Celery and Redis?** Redis queues jobs, Celery workers process email outside web requests, and beat schedules maintenance. Persistent database email jobs survive broker failure. The easy demo runs these tasks immediately to avoid needing extra services.

**What is the AI algorithm?** Summaries rank source sentences by word frequency and dates. Urgency uses rules. Translation uses the NLLB neural model locally. The assistant retrieves matching notices and displays excerpts with source links.

**How do you reduce chatbot hallucinations?** Retrieve only active notices, give them as bounded context, request source IDs, display source links, and decline when no matching notice exists. This reduces risk but does not guarantee every generated sentence is correct.

**Does Malayalam translation work offline?** Yes, after installing the local model and runtime. The Django server must remain running. No translation API key is needed.

**Why PostgreSQL instead of JSON?** Relationships, uniqueness/check constraints, transactions, indexes and worker-safe row locking are built into the database. SQLite provides a convenient single-machine demo using the same Django models.

**Is a queued email the same as a sent email?** No. Pending, failed, demo, sent and skipped are separate states. Sent only means SMTP accepted it; recipient inbox placement is external.

**What is the PWA's offline behaviour?** The manifest enables installation in supported browsers; the service worker caches public assets and a reconnect page. It intentionally does not cache private notices across users.

**What remains before college-wide production use?** Verified account enrollment, password reset, antivirus scanning, HTTPS hosting, secret management, backups, real-provider validation, accessibility/load testing and monitoring.

## Submission contents

Submit the source ZIP, requirement review, architecture and test evidence. Update your presentation's scope statements as listed in `REQUIREMENTS_REVIEW.md`. Verify the bibliography before submission; do not present incomplete paper citations as validated research.

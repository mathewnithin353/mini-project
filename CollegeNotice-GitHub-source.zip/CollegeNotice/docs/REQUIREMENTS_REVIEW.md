# Presentation-to-project review

Reviewed 6 October 2026. Reference: the supplied 20-page `notice_board_review 1.pdf` and the original `zmo7t2` source folder. The PDF is treated as a project specification and evidence, not as authority to run instructions embedded in a document.

## Verdict on the supplied project

The original project was a partial Next.js prototype, not an implementation of the architecture described in the presentation. Rebuilding was justified after the user explicitly selected the Django stack.

| Presentation requirement | Original source evidence | Rebuilt implementation and verification |
|---|---|---|
| Django + DRF backend (slides 1, 8, 9, 11) | `package.json` specifies Next.js/React; API routes are TypeScript | Django + DRF REST API implemented; local tests and browser verification |
| PostgreSQL relational storage | `lib/store.ts` reads/writes `data/db.json` | Django models, foreign keys, uniqueness/check constraints and migration; PostgreSQL Compose configuration; SQLite used for local verification |
| Celery + Redis | No worker, broker or scheduler in project | Celery app, Redis configuration, worker and beat containers, archival/outbox tasks; eager mode tested; distributed runtime not tested here |
| Secure roles and JWT | Passwords compared as plaintext; a default signing secret and custom token parser | Django password hashes, CSRF-protected sessions, standard SimpleJWT, throttled login, department restrictions; tested |
| Create/edit/delete, tags and expiry | Basic CRUD existed; sparse validation and no department ownership enforcement | Validated CRUD, protected catalogue relationships, archive/restore, expiry hidden on every query; tested |
| Smart alerts (slide 3) | Stored objects called emails; no SMTP sender | Persistent in-app alerts, 10-second browser polling, real SMTP adapter, email job statuses/retries; local/mocked tests. Strict instant push remains outside scope |
| Search and filters | Basic UI filtering/search present | Server-side keyword, department, category, date, priority and saved filters; pagination; tested |
| AI summary and priority | Simple truncation and regex urgency | Local word-frequency summaries, date weighting and urgency rules |
| Malayalam-to-English | External request with truncation | Local NLLB translation in both directions, verified live; student notice and Assistant translation controls |
| Notice chatbot | Keyword matching | Local retrieval with source links and optional local answer translation; cloud provider removed at user request |
| Admin dashboard and attachments | Basic counts and upload handling | Department statistics, categories, email status, audit log, CSV export, validated private attachments; tested |
| Student bookmarks/profile (slides 4, 10, 16) | Basic support | Per-user bookmarks, registration, profile preferences and password changes; tested |
| Responsive PWA | Manifest lacked icons; `public/sw.js` unregistered itself | Responsive interface, complete icons/manifest, registered worker and offline fallback. Offline private notice reading and background push are not claimed |
| Cloud storage/deployment/encrypted data (slide 9) | No configured cloud infrastructure | Local protected media volume; deployment configuration documented. No cloud deployment, cloud file storage or at-rest encryption claim |

## Objective assessment

1. **Automate notice lifecycle:** implemented. Students cannot retrieve expired or archived notices, even before the scheduler runs. Celery beat persists expiry archival once per minute. Manual archival and restoration are available to authorised admins.
2. **Enable smart alerts:** implemented as persistent alerts with 10-second near-real-time polling. SMTP is supported and asynchronous in Docker mode; real delivery requires configuration. This is not instantaneous WebSocket/push delivery.
3. **Provide intelligent filtering:** implemented and tested against actual persisted records.
4. **Deliver AI assistance:** local NLP, source-based notice search and NLLB English–Malayalam translation work without API credentials. Cloud integration was removed at the user’s request.
5. **Empower administrators:** implemented, with more restrictive and testable department permissions than the original.
6. **Ensure anywhere access:** responsive PWA implemented for supported browsers; actual off-campus access still requires HTTPS hosting. Offline mode provides a reconnect screen rather than caching private institutional content.

The project is suitable for a local mini-project demonstration. Do not label every cloud/external integration as verified simply because the code and environment variables exist.

## Corrections needed in the presentation

- Explain the distinction between the SQLite demo and the PostgreSQL/Celery deployment profile.
- Replace “real-time alerts” with “near-real-time in-app alerts (10-second refresh)” unless true push is added and tested.
- Explain the local translation model and extractive NLP. Do not call regex urgency a trained classifier.
- Change “encrypted data” to “hashed passwords and HTTPS-ready deployment configuration”; at-rest encryption depends on the host/database setup.
- Describe attachments as protected local/volume storage. Cloud object storage is a future enhancement.
- Use the actual model names and cardinalities in `ARCHITECTURE.md`. In particular, a department has many notices; each notice belongs to zero or one department (null means campus-wide).
- The source deck mixes `/18` and `/20` slide counters. Standardise to 20 slides.
- Slide 5 contains incomplete literature citations and spelling errors. Bibliographic claims were not independently verified in this code audit. Verify each cited paper's title, authors, year, venue and DOI/URL before submitting.
- Diagrams mention results/download results beyond the explicit core modules. This rebuild does not add a separate marks/results system; file downloads belong to notices.

The original source and PDF in Downloads were left unchanged. The rebuilt project is a separate deliverable.

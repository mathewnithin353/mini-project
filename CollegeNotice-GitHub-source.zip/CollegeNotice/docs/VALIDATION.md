# Validation record

Date: 6 October 2026. Environment: Windows, Python 3.12, Django 5.2.17, SQLite, eager Celery tasks. External AI credentials were not configured. Email used a local/demo backend; the SMTP success path was mocked.

## Automated results

```text
python manage.py test board --verbosity 1
Found 36 test(s).
Ran 36 tests in 63.456s
OK

python manage.py makemigrations --check --dry-run
No changes detected

python manage.py check
System check identified no issues (0 silenced).
```

All three frontend JavaScript files also passed syntax checks. Database migrations applied successfully, demonstration data loaded, and static assets were collected successfully.

The automated tests cover unauthenticated access, password hashing, student write denial, cross-department write denial, campus-wide publication, date/catalogue validation, expiry without scheduler execution, archive/restore, search/filtering, user-scoped bookmarks, notification ownership/idempotency, email opt-out/retry/status, attachment validation/private download/removal, cascading deletion, catalogue protection, role escalation prevention, registration, password changes, CSRF, JWT, chat sources, Malayalam fallback, provider failure, CSV formula escaping, dashboard permissions, time abbreviations and deadline detection.

The first run exposed an administrator incorrectly receiving student alerts through a default role value; recipient selection now excludes superusers. Browser review exposed time abbreviations being split from their venue and an unrecognised “submit your report by” deadline; both received fixes and regression tests.

## Browser verification

- Administrator demo login succeeded.
- Notice board displayed persisted notices, Malayalam text, priority flags and service-mode labels.
- A fictional “Project demo verification” notice was published through the actual form; the refreshed board displayed it.
- Dashboard showed the new notice, activity entry and demo email job.
- Notice assistant returned the matching seminar with a source button.
- Desktop layout inspected at 1366 × 900.
- Phone layout inspected at 390 × 844. Measured document width: 375 CSS pixels within a 390-pixel viewport; no horizontal page overflow. The mobile navigation itself intentionally scrolls horizontally.
- Final server restart and page reload showed the corrected summaries retaining time and venue together.
- Screenshots are in `docs/screenshots/`. They may include the explicitly labelled fictional verification notice; a fresh installation seeds only the packaged demonstration records.

## Limits of this validation

- PostgreSQL, Docker containers, Redis broker, Celery worker/beat integration: configured, not run here because Docker/PostgreSQL were unavailable.
- OpenAI summaries/chat/translation: adapter paths tested with controlled responses and failures; no live provider request or translation-quality evaluation.
- SMTP: local failure/retry/status logic tested; no real email sent and no deliverability claim.
- PWA: assets/manifest/worker supplied and loaded; no device installation or browser-offline simulation was performed. Offline private-notice reading is not implemented.
- Windows launcher: reviewed, and its migration/seeding/static/server steps exercised with the project environment; a fresh double-click installation on a clean computer was not run.
- No public cloud deployment, at-rest encryption, malware scanning, formal accessibility audit or concurrent-user/load test.

For submission, retain these distinctions. Passing a local test suite is evidence of local behaviour, not proof of deployment or external-service availability.


## Translation and Gmail update — 11 October 2026

Added both translation directions, a language label in the notice API/UI, structured provider output and incomplete-response rejection. Added a configuration-check command with explicit opt-in API and single-recipient email tests. Eleven isolated automated tests pass for translation direction, fallback, request shape and email command behaviour. These tests mock external providers; real OpenAI/Gmail connections require credentials and have not been tested. Django system checks and frontend syntax checks pass. The full database suite could not be rerun in this session because Windows denied path resolution for a third-party SimpleJWT migration in the installed virtual environment. No database schema changes were required.


## Azure Translator update — 11 October 2026

Added an explicit Azure translation provider with global/regional resource authentication, safe error messages, English/Malayalam target selection, and original-text fallback. Azure mode uses local summaries, priorities and chatbot answers without invoking OpenAI. The local .env and distribution example select Azure; Gmail credentials are preserved. All 18 isolated service tests pass (11 existing and 7 Azure tests), including mocked requests, both target languages, headers, missing keys, malformed results, secret redaction and the two-direction command. Django checks pass. No database schema change. Azure live integration remains untested until a resource key is supplied; no Azure account, subscription or paid resource was created.


## Local translation update — 11 October 2026

Installed CTranslate2 4.8.2, SentencePiece 0.2.2, NumPy 2.5.4 and PyYAML 6.0.3 in the project environment. Downloaded the pinned NLLB int8 model; verified published SHA-256 hashes for model/tokenizer and PyPI wheel downloads. Four real word/sentence translations passed in both directions with Python socket connection and urllib requests blocked. Recorded input/output/timing in local-translation-samples.json. The normal two-direction check_services command also passed. No cloud translation API was called for these checks.

Added the authenticated Translate text endpoint/page and automatic local translation for saved notices. Twenty-eight isolated service tests pass, covering request validation/authentication, both language directions, long-input chunk coverage, failure fallback and cloud-provider compatibility. JavaScript syntax and Django system checks pass. The database suite was not rerun because of the previously documented Windows migration-file access issue. Browser rendering of the new page was not verified in this session. No notices were published and no email was sent during this update.

The source ZIP excludes the approximately 630 MB model, the Python environment and .env. These are installed locally on the review computer. Other computers need setup-local-translation.bat or a copy of the model directory.


## Browser verification — 11 October 2026

Resolved a missing Translate text menu caused by stale collected JavaScript: ran collectstatic and reloaded the page. Signed in through the normal demo login, opened Translate text, and submitted “The library opens tomorrow.” The live endpoint returned “ലൈബ്രറി നാളെ തുറക്കും.” Verified the result in the browser; screenshot: translator-working.png. This completes the previously outstanding browser check for the new page. No notice was published and no email sent.

## Student notice translation — 11 October 2026
- Added authenticated per-notice translation using the existing visible-notice lookup; no notice writes or email dispatch.
- Student reader shows Translate to Malayalam/English; separate text translator is in the student navigation.
- Django system check and 32 service/translation tests passed, including student access, both directions, stored translation reuse, login and failure handling.
- Browser verified the student notice dialog displaying Malayalam for MCA mini-project review guidelines. Screenshot: student-notice-translation.png.


## Assistant translation and search — 11 October 2026
- Assistant answers include an English/Malayalam translation button. Verified a Malayalam answer in the student browser; original text and sources remain available.
- Search combines department, category, inclusive publication-date range and all supplied keywords, regardless of order. Reversed date ranges are rejected.
- Browser verified review project + Computer Applications + Academic + 2 October 2026 returns the review notice.
- JavaScript syntax and Django system checks passed. Database filter test could not start because the SimpleJWT migration path raised Windows PermissionError; browser verification completed instead.


## Local-only cleanup — 11 October 2026
Removed the external translation integrations, credentials and dependency at user request. Earlier cloud-provider entries above are historical. Current validation: 21 local translation/service tests pass, system check passes, and real English/Malayalam local samples pass. Gmail configuration preserved; no email sent.

## Deliver AI Assistance — 11 October 2026
Verified local extractive summaries, English/Malayalam priority rules, local neural translation and source-based chatbot answers. Fixed tokenization to preserve Malayalam combining marks during summary scoring and chatbot search. All 26 focused assistance/translation/service tests passed; actual English–Malayalam model checks passed. The chatbot retrieves excerpts; it is not an unrestricted generative model.


# Architecture and API

## System overview

```mermaid
flowchart LR
    U[Student / Department admin] --> P[Responsive PWA]
    P -->|Session + CSRF| A[Django REST API]
    C[External API client] -->|JWT| A
    A --> DB[(PostgreSQL)]
    A --> F[Protected media volume]
    A --> N[Local NLP and NLLB translation]
    A -->|After transaction commits| R[Redis broker]
    R --> W[Celery worker]
    B[Celery beat] --> R
    W --> DB
    W --> S[SMTP / demo email files]
```

For the easy local demo, SQLite replaces PostgreSQL and Celery tasks execute immediately in the web process. Expired notices are always excluded by queries. The persisted archive sweep and failed-email retries use Celery beat in the full stack or the `maintenance` management command locally.

The browser polls notifications every ten seconds while visible. It does not keep JWTs in browser storage: Django's HttpOnly session cookie and CSRF token protect browser requests. JWT endpoints exist for separate API clients.

## Data model

```mermaid
erDiagram
    DEPARTMENT o|--o{ USER : assigned_to
    DEPARTMENT o|--o{ NOTICE : targets
    CATEGORY ||--o{ NOTICE : classifies
    USER ||--o{ NOTICE : creates
    USER ||--o{ BOOKMARK : saves
    NOTICE ||--o{ BOOKMARK : saved_as
    USER ||--o{ NOTIFICATION : receives
    NOTICE ||--o{ NOTIFICATION : triggers
    USER ||--o{ EMAIL_DELIVERY : receives
    NOTICE ||--o{ EMAIL_DELIVERY : queues
    USER o|--o{ ACTIVITY : performs
```

- A null notice department means a campus-wide notice; only superusers can publish it.
- The user extends Django's AbstractUser. Passwords are hashes, never plaintext.
- Notice stores source body, derived summary/translation, priority reason, author, category, publication/expiry dates and attachment metadata.
- Database uniqueness constraints enforce one bookmark, notification and email delivery per user/notice pair.
- Deleting a notice cascades its bookmarks, notifications and email jobs. In-use categories, departments and authors are protected from deletion.
- The expiry date has a database check constraint and serializer validation. Dates use Asia/Kolkata, with expiry inclusive through that date.
- An attachment receives a random storage name. The public web server does not expose the media directory.
- Activity is retained after a notice is deleted and shows the action and author.

## Publish sequence

1. Authenticate and validate role, target department, content, dates, category and optional attachment.
2. Derive the summary and priority locally, then translate with the installed NLLB model. If the model is unavailable, preserve the original notice and report the failure.
3. Within a database transaction, save the notice, activity record, student alerts and persistent email jobs.
4. After commit, request outbox processing. A broker failure does not discard the saved jobs.
5. The worker checks each pending job and current student preferences. It records demo, sent, failed or skipped status.
6. The browser's next notification refresh shows the unread alert.

The email sender uses row locking on PostgreSQL to avoid concurrent workers processing the same pending row. SMTP is not an exactly-once system: a process failure after SMTP acceptance but before the database commit can result in a duplicate on retry. The mini project documents this limitation rather than claiming guaranteed delivery.

## API quick reference

All routes end in `/`. Authenticated APIs use session + CSRF or `Authorization: Bearer <access-token>`. List responses from `/api/notices/` contain `count`, `next`, `previous`, `results` with 12 notices per page.

| Method | Endpoint | Behaviour |
|---|---|---|
| GET | /api/bootstrap/ | Current user, catalogue and honest service-mode labels |
| POST | /api/auth/register/ | Student-only account creation; name, email, password, department |
| POST | /api/auth/login/ | Browser login; email and password; requires CSRF |
| POST | /api/auth/logout/ | End browser session |
| POST | /api/auth/token/ | JWT pair; username (the email for normal application accounts) and password |
| POST | /api/auth/token/refresh/ | Rotate refresh token |
| POST | /api/auth/token/revoke/ | Blacklist refresh token; access token lasts at most 15 minutes |
| GET/PATCH | /api/profile/ | Read profile; change name and email_alerts only |
| POST | /api/password/ | current_password, new_password |
| GET/POST | /api/notices/ | List active notices / publish |
| GET/PATCH/DELETE | /api/notices/{id}/ | Read / update / delete |
| POST/DELETE | /api/notices/{id}/bookmark/ | Save / remove saved notice |
| GET | /api/notices/{id}/attachment/ | Authenticated attachment download |
| GET/POST | /api/notifications/ | List alerts / mark all or one `id` read |
| POST | /api/chat/ | `question`; returns reply, sources and mode |
| GET/POST | /api/dashboard/ | Admin stats / retry failed email jobs |
| GET | /api/export/ | Admin CSV report |
| GET/POST/PATCH/DELETE | /api/departments/ and /api/categories/ | Read catalogue; admin writes (detail IDs for patch/delete) |

Notice filters: `q`, `department` (numeric ID or `campus`), `category`, `from`, `to`, `priority=1`, `saved=1`, `state=archived` (admin), and `page`.

Notice create/update accepts multipart form data for attachments. Text and date fields also accept JSON. Use `force_priority=true` to override automatic priority, `clear_attachment=true` to remove a file, and `archived=true/false` to archive/restore. Restore an expired notice only after extending its expiry date.

## Implementation references

- Django deployment checklist: https://docs.djangoproject.com/en/5.2/howto/deployment/checklist/
- Celery Django integration and transaction commit hooks: https://docs.celeryq.dev/en/latest/django/first-steps-with-django.html

These official references were consulted for implementation. They do not establish that this project has been deployed or that its external integrations have been exercised with real credentials.

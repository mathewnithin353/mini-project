"""Local Windows/macOS/Linux demo launcher. No keys, admin rights or Docker required."""
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import urllib.request
import venv
import webbrowser

def main():
    if sys.version_info < (3, 11):
        raise RuntimeError('Python 3.11 or newer is required. Python 3.12 is recommended.')
    root = Path(__file__).resolve().parent
    os.chdir(root)
    env_dir = root / '.venv'
    python = env_dir / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    if not python.exists():
        print('Creating the project environment...')
        venv.create(env_dir, with_pip=True)
    requirements = root / 'requirements.txt'
    digest = hashlib.sha256(requirements.read_bytes()).hexdigest()
    stamp = env_dir / '.requirements-sha256'
    def run(*args):
        subprocess.run([str(python), *args], check=True)
    if not stamp.exists() or stamp.read_text() != digest:
        print('Installing project dependencies (internet is needed on the first run)...')
        run('-m', 'pip', 'install', '-r', str(requirements))
        stamp.write_text(digest)
    run('manage.py', 'migrate', '--noinput')
    # Seed command is deliberately disabled when DEMO_MODE=0.
    run('manage.py', 'shell', '-c', 'from django.conf import settings; from django.core.management import call_command; call_command("seed_demo") if settings.DEMO_MODE else None')
    run('manage.py', 'collectstatic', '--noinput')
    port = int(os.getenv('PORT', '8001'))
    url = f'http://127.0.0.1:{port}/'
    def open_when_ready():
        for _ in range(60):
            try:
                with urllib.request.urlopen(url, timeout=1) as response:
                    if response.status == 200:
                        webbrowser.open(url)
                        return
            except OSError:
                time.sleep(1)
    threading.Thread(target=open_when_ready, daemon=True).start()
    print(f'CollegeNotice: {url}\nKeep this window open. Press Ctrl+C to stop.')
    try:
        run('manage.py', 'runserver', f'127.0.0.1:{port}', '--noreload')
    except KeyboardInterrupt:
        pass

if __name__ == '__main__':
    main()


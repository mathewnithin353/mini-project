@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Please run start.bat once to create the Python environment.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" setup_local_chat.py
if errorlevel 1 (
  echo Setup did not finish. Run this file again to resume the download.
  pause
  exit /b 1
)
echo General chat is ready. Open start.bat and select AI assistant.
pause

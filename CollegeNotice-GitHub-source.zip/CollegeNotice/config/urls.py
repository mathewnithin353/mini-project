from django.contrib import admin
from django.urls import include, path
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView, TokenBlacklistView
from board import views

router = DefaultRouter()
router.register('notices', views.NoticeViewSet, basename='notice')
router.register('departments', views.Departments)
router.register('categories', views.Categories)

urlpatterns = [
    path('api/translate/', views.TranslateText.as_view()),
    path('', views.index), path('sw.js', views.service_worker), path('admin/', admin.site.urls),
    path('api/bootstrap/', views.Bootstrap.as_view()), path('api/auth/login/', views.Login.as_view()),
    path('api/auth/register/', views.Register.as_view()), path('api/auth/logout/', views.Logout.as_view()),
    path('api/auth/token/', views.ThrottledTokenLogin.as_view()), path('api/auth/token/refresh/', TokenRefreshView.as_view()),
    path('api/auth/token/revoke/', TokenBlacklistView.as_view()),
    path('api/profile/', views.Profile.as_view()), path('api/password/', views.ChangePassword.as_view()),
    path('api/notifications/', views.Notifications.as_view()), path('api/chat/', views.Chat.as_view()),
    path('api/dashboard/', views.Dashboard.as_view()), path('api/export/', views.Export.as_view()),
    path('api/', include(router.urls)),
]

"""One-time, explicit download of the portable local chat runtime and model."""
import hashlib
from pathlib import Path
import time
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT = Path(__file__).resolve().parent / 'local-models' / 'chat'
MODEL = 'qwen2.5-3b-instruct-q4_k_m.gguf'
ASSETS = [
    ('llama-runtime.zip', 'https://github.com/ggml-org/llama.cpp/releases/download/b11609/llama-b11609-bin-win-cpu-x64.zip', '8708a7b81842333927f6377ac3f17ff8bba4dbe1ee0cf28dfd5e7a32e3a46b38'),
    (MODEL, 'https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/' + MODEL, '626b4a6678b86442240e33df819e00132d3ba7dddfe1cdc4fbb18e0a9615c62d'),
]

def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

def download_model(url, target, expected):
    # Bounded range requests preserve progress across interrupted downloads.
    total = 2104932768
    partial = target.with_suffix('.gguf.part')
    prefix = partial.stat().st_size if partial.exists() else 0
    chunks = ROOT / 'download-chunks'
    chunks.mkdir(exist_ok=True)
    ranges = [(start, min(start + 32 * 1048576, total) - 1)
              for start in range(prefix, total, 32 * 1048576)]
    def fetch(bounds):
        start, end = bounds
        output = chunks / f'{start}-{end}.part'
        if output.exists() and output.stat().st_size == end - start + 1:
            return output
        for attempt in range(4):
            try:
                request = urllib.request.Request(url, headers={'Range': f'bytes={start}-{end}'})
                with urllib.request.urlopen(request, timeout=60) as response:
                    if response.status != 206 or response.headers.get('Content-Range') != f'bytes {start}-{end}/{total}':
                        raise ValueError('Unexpected download range')
                    with output.open('wb') as file:
                        while chunk := response.read(1024 * 1024):
                            file.write(chunk)
                if output.stat().st_size != end - start + 1:
                    raise ValueError('Incomplete download range')
                return output
            except Exception:
                if attempt == 3:
                    raise
                time.sleep(2)
    completed = prefix
    with ThreadPoolExecutor(max_workers=8) as workers:
        jobs = [workers.submit(fetch, bounds) for bounds in ranges]
        for job in as_completed(jobs):
            completed += job.result().stat().st_size
            print(f'Model: {completed // 1048576} / {total // 1048576} MB', flush=True)
    assembled = target.with_suffix('.gguf.complete')
    with assembled.open('wb') as result:
        inputs = ([partial] if prefix else []) + [chunks / f'{start}-{end}.part' for start, end in ranges]
        for source_path in inputs:
            with source_path.open('rb') as source:
                while chunk := source.read(4 * 1048576):
                    result.write(chunk)
    if digest(assembled) != expected:
        raise ValueError('Model checksum mismatch')
    assembled.replace(target)
    # Remove only the exact temporary files just assembled, after verification.
    for source_path in inputs:
        source_path.unlink()
    print('Local model download verified.', flush=True)

def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    for name, url, expected in ASSETS:
        target = ROOT / name
        if target.exists() and digest(target) == expected:
            print(name + ': verified existing file.', flush=True)
            continue
        if name == MODEL:
            download_model(url, target, expected)
            continue
        partial = target.with_suffix(target.suffix + '.part')
        for attempt in range(4):
            try:
                start = partial.stat().st_size if partial.exists() else 0
                req = urllib.request.Request(url, headers={'Range': f'bytes={start}-'} if start else {})
                with urllib.request.urlopen(req, timeout=60) as response:
                    append = response.status == 206 and start > 0
                    count = start if append else 0
                    last = time.monotonic()
                    with partial.open('ab' if append else 'wb') as output:
                        while chunk := response.read(1024 * 1024):
                            output.write(chunk)
                            count += len(chunk)
                            if time.monotonic() - last > 10:
                                print(f'{name}: {count // 1048576} MB downloaded', flush=True)
                                last = time.monotonic()
                if digest(partial) != expected:
                    partial.unlink()
                    raise ValueError('Download checksum mismatch.')
                partial.replace(target)
                print(name + ': download verified.', flush=True)
                break
            except Exception as error:
                if attempt == 3:
                    raise
                print(f'Retrying download: {type(error).__name__}', flush=True)
                time.sleep(2)
    runtime = ROOT / 'runtime'
    runtime.mkdir(exist_ok=True)
    with zipfile.ZipFile(ROOT / 'llama-runtime.zip') as archive:
        for item in archive.infolist():
            destination = (runtime / item.filename).resolve()
            if not destination.is_relative_to(runtime.resolve()):
                raise ValueError('Unexpected archive path')
        archive.extractall(runtime)
    print('Local chat model and runtime are ready. Restart CollegeNotice.', flush=True)

if __name__ == '__main__':
    main()

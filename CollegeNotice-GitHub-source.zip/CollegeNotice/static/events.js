async function refreshCatalog(){const d=await api('/api/bootstrap/');state.departments=d.departments;state.categories=d.categories;}
async function ask(question){
 question=question?.trim();if(state.asking||!question)return;
 const chatMode=state.chatMode||'general', owner=state.user?.id, token=(state.chatVersion||0);
 const history=[];let size=0;
 for(const m of state.messages.slice().reverse()){
  if(m.failed)continue;
  const content=m.text.slice(0,3000);if(history.length>=8||size+content.length>6000)break;
  history.unshift({role:m.role,content});size+=content.length;
 }
 state.asking=true;state.messages.push({role:'user',text:question});$('#content').innerHTML=assistant();scrollChat();
 try{
  const d=await api('/api/chat/',{method:'POST',body:{question,mode:chatMode,history}});
  if(state.user?.id===owner&&(state.chatVersion||0)===token)state.messages.push({role:'assistant',text:d.reply,mode:d.mode,sources:d.sources});
 }catch(e){if(state.user?.id===owner&&(state.chatVersion||0)===token)state.messages.push({role:'assistant',text:e.message,mode:'Request failed',failed:true});}
 finally{if((state.chatVersion||0)===token)state.asking=false;}
 if(state.user?.id===owner&&state.route==='assistant'){$('#content').innerHTML=assistant();scrollChat();$('#chat-form [name=question]')?.focus();}
}

document.addEventListener('submit',async event=>{
 event.preventDefault();const form=event.target,submit=form.querySelector('[type=submit]'),error=form.querySelector('.form-error');if(error)error.textContent='';if(submit)submit.disabled=true;
 try{
  const fields=Object.fromEntries(new FormData(form));
  if(form.id==='auth-form'){if(state.register)fields.department=Number(fields.department);await api(`/api/auth/${state.register?'register':'login'}/`,{method:'POST',body:fields});state.route='board';state.filters={};await bootstrap();}
  else if(form.id==='filter-form'){state.filters=fields;state.page=1;await navigate(state.route,true);}
  else if(form.id==='notice-form'){
   const body=new FormData(form);body.set('force_priority',form.elements.force_priority.checked?'true':'false');body.set('clear_attachment',form.elements.clear_attachment?.checked?'true':'false');if(!body.get('attachment')?.size)body.delete('attachment');
   if(submit)submit.textContent='Saving…';
   await api(state.editId?`/api/notices/${state.editId}/`:'/api/notices/',{method:state.editId?'PATCH':'POST',body});$('#dialog').close();toast(state.editId?'Notice updated.':'Notice published. Department alerts created.');await navigate(state.route);
  }
  else if(form.id==='profile-form'){state.user=await api('/api/profile/',{method:'PATCH',body:{name:fields.name,email_alerts:form.elements.email_alerts.checked}});shell();await navigate('profile');toast('Profile saved.');}
  else if(form.id==='password-form'){await api('/api/password/',{method:'POST',body:fields});form.reset();toast('Password changed.');}
  else if(form.id==='chat-form')await ask(fields.question);
  else if(form.id==='translation-form'){
   submit.textContent='Translating locally…';
   $('#translation-output').textContent='Translating…';
   try{const result=await api('/api/translate/',{method:'POST',body:fields});if(form.isConnected)$('#translation-output').textContent=result.translation;}
   catch(e){if(form.isConnected)$('#translation-output').textContent='Translation was not completed.';throw e;}
   finally{submit.textContent='Translate';}
  }
  else if(form.classList.contains('catalog-form')){await api(`/api/${form.dataset.kind}/`,{method:'POST',body:fields});await refreshCatalog();await navigate('catalog');toast('Catalogue updated.');}
 }catch(e){if(error)error.textContent=e.message;else toast(e.message);if(form.id==='notice-form'&&submit)submit.textContent=state.editId?'Save changes':'Publish notice';}finally{if(submit)submit.disabled=false;}
});
document.addEventListener('click',async event=>{
 const el=event.target.closest('[data-action],[data-route]');if(!el||el.disabled)return;
 try{
  if(el.dataset.route){await navigate(el.dataset.route);return;}
  const action=el.dataset.action,id=el.dataset.id;
  if(action==='switch-auth'){state.register=!state.register;auth();}
  else if(action==='demo'){$('#auth-form [name=email]').value=el.dataset.role+'@college.test';$('#auth-form [name=password]').value='College@12345';$('#auth-form [type=submit]').focus();}
  else if(action==='logout'){await api('/api/auth/logout/',{method:'POST'});state.user=null;state.messages=[];state.chatVersion=(state.chatVersion||0)+1;state.asking=false;state.notices=[];state.notifications=[];state.unread=0;state.register=false;auth();}
  else if(action==='refresh')await navigate(state.route,true);
  else if(action==='page'){state.page=Number(el.dataset.page);await navigate(state.route,true);window.scrollTo(0,0);}
  else if(action==='reset'){state.filters={};await navigate(state.route);}
  else if(action==='open'||action==='source')await openNotice(id);
  else if(action==='save'){el.disabled=true;const n=state.notices.find(n=>n.id===Number(id));await api(`/api/notices/${id}/bookmark/`,{method:n.bookmarked?'DELETE':'POST'});n.bookmarked=!n.bookmarked;el.classList.toggle('saved',n.bookmarked);el.textContent=n.bookmarked?'♥ Saved':'♡ Save';el.setAttribute('aria-label',(n.bookmarked?'Unsave ':'Save ')+n.title);el.disabled=false;if(state.route==='saved')await navigate('saved');}
  else if(action==='close')$('#dialog').close();
  else if(action==='compose')composer();
  else if(action==='translate-notice'){
   const noticeId=Number(id);el.disabled=true;const label=el.textContent;el.textContent='Translating…';
   try{const result=await api(`/api/notices/${noticeId}/translate/`,{method:'POST',body:{}});if(state.openNotice?.id===noticeId&&$('#notice-translation'))$('#notice-translation').textContent=result.translation;}
   catch(e){if(state.openNotice?.id===noticeId&&$('#notice-translation'))$('#notice-translation').textContent=e.message;}
   finally{el.disabled=false;el.textContent=label;}
  }
  else if(action==='edit')composer(state.openNotice);
  else if(action==='delete'){if(confirm('Permanently delete this notice, its attachment, bookmarks and alerts?')){await api(`/api/notices/${id}/`,{method:'DELETE'});$('#dialog').close();toast('Notice deleted.');await navigate(state.route);}}
  else if(action==='archive'){await api(`/api/notices/${id}/`,{method:'PATCH',body:{archived:state.openNotice.is_active}});$('#dialog').close();toast('Notice status updated.');await navigate(state.route);}
  else if(action==='read-all'){await api('/api/notifications/',{method:'POST',body:{}});await navigate('notifications');}
  else if(action==='notification'){await api('/api/notifications/',{method:'POST',body:{id:Number(id)}});await notifications();if(state.route==='notifications')$('#content').innerHTML=inbox();try{await openNotice(el.dataset.notice);}catch{toast('This notice has expired or is no longer available.');}}
  else if(action==='suggest')await ask(el.dataset.question);
  else if(action==='new-chat'||action==='chat-mode'){
   if(state.asking)return;
   state.messages=[];state.chatVersion=(state.chatVersion||0)+1;
   if(action==='chat-mode')state.chatMode=el.dataset.mode;
   $('#content').innerHTML=assistant();$('#chat-form [name=question]').focus();
  }
  else if(action==='copy-answer'){
   const message=state.messages[Number(id)];if(!message||message.role!=='assistant')return;
   await navigator.clipboard.writeText(message.text);toast('Answer copied.');
  }
  else if(action==='translate-answer'){
   const message=state.messages[Number(id)];if(!message||message.role!=='assistant'||message.translating)return;
   const target=/[\u0D00-\u0D7F]/.test(message.text)?'en':'ml';
   message.translating=true;el.disabled=true;el.textContent='Translating…';
   try{const result=await api('/api/translate/',{method:'POST',body:{text:message.text,target}});message.translation=result.translation;message.translationError='';}
   catch(e){message.translationError=e.message;}
   finally{message.translating=false;if(state.route==='assistant'&&state.messages[Number(id)]===message){const output=document.getElementById(`answer-translation-${id}`);if(output)output.innerHTML=answerTranslation(message,Number(id));}}
  }
  else if(action==='retry-emails'){el.disabled=true;await api('/api/dashboard/',{method:'POST',body:{}});toast('Email retries requested.');await navigate('dashboard');}
  else if(action==='delete-catalog'){if(confirm('Delete this unused catalogue item?')){await api(`/api/${el.dataset.kind}/${id}/`,{method:'DELETE'});await refreshCatalog();await navigate('catalog');}}
  else if(action==='rename-catalog'){const item=state[el.dataset.kind].find(i=>i.id===Number(id)),name=prompt('New name',item.name);if(name?.trim()){await api(`/api/${el.dataset.kind}/${id}/`,{method:'PATCH',body:{name:name.trim()}});await refreshCatalog();await navigate('catalog');}}
  else if(action==='install'&&installEvent){await installEvent.prompt();installEvent=null;el.hidden=true;}
 }catch(e){toast(e.message);el.disabled=false;}
});
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installEvent=event;const button=$('#install');if(button)button.hidden=false;});
window.addEventListener('offline',()=>toast('You are offline. Reconnect to load and save notices.'));
if('serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});
bootstrap().catch(e=>{$('#app').innerHTML=empty('CollegeNotice could not start',esc(e.message))+'<p style="text-align:center"><a href="/">Try again</a></p>';});
